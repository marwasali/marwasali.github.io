<?php
class Record {
    private $conn;
    private $table = "records";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM {$this->table} ORDER BY RECORDSID DESC");
            $stmt->execute();
            return $stmt;
        } catch (PDOException $e) {
            error_log("Error in getAll: " . $e->getMessage());
            return false;
        }
    }

    public function create($data) {
        try {
            $sql = "INSERT INTO {$this->table} 
                    (patient_name, doctor_name, record_date, diagnosis, treatment) 
                    VALUES (:patient, :doctor, :date, :diagnosis, :treatment)";
            
            $stmt = $this->conn->prepare($sql);
            
            // Bind parameters
            $stmt->bindParam(':patient', $data['patient']);
            $stmt->bindParam(':doctor', $data['doctor']);
            $stmt->bindParam(':date', $data['date']);
            $stmt->bindParam(':diagnosis', $data['diagnosis']);
            $stmt->bindParam(':treatment', $data['treatment']);
            
            $result = $stmt->execute();
            
            // Check if insert was successful
            if ($result && $this->conn->lastInsertId()) {
                return true;
            }
            return false;
            
        } catch (PDOException $e) {
            error_log("Error in create: " . $e->getMessage());
            return false;
        }
    }

    public function update($data) {
        try {
            $sql = "UPDATE {$this->table} SET
                    patient_name = :patient,
                    doctor_name = :doctor,
                    record_date = :date,
                    diagnosis = :diagnosis,
                    treatment = :treatment
                    WHERE RECORDSID = :id";
            
            $stmt = $this->conn->prepare($sql);
            
            // Bind parameters
            $stmt->bindParam(':id', $data['id']);
            $stmt->bindParam(':patient', $data['patient']);
            $stmt->bindParam(':doctor', $data['doctor']);
            $stmt->bindParam(':date', $data['date']);
            $stmt->bindParam(':diagnosis', $data['diagnosis']);
            $stmt->bindParam(':treatment', $data['treatment']);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log("Error in update: " . $e->getMessage());
            return false;
        }
    }

    public function delete($id) {
        try {
            $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE RECORDSID = ?");
            return $stmt->execute([$id]);
        } catch (PDOException $e) {
            error_log("Error in delete: " . $e->getMessage());
            return false;
        }
    }
}
?>

