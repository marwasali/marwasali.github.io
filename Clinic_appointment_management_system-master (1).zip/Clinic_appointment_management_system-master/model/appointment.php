<?php
class Appointment
{
    private $conn;
    private $table_name = "book_app";

    // Properties matching your table structure exactly
    public $APPID;
    public $Pemail;      // Changed from Email to match Pemail in table
    public $Pphone;      // Changed from Phone to match Pphone in table
    public $APPplace;    // Changed from AppPlace to match APPplace in table
    public $APPdate;     // Changed from AppDate to match APPdate in table
    public $APPtime;     // Changed from AppTime to match APPtime in table
    public $APPreason;   // Changed from AppReason to match APPreason in table
    public $status;      // Changed from Status to match status in table (lowercase)

    public function __construct($db)
    {
        $this->conn = $db;
    }

    // Create new appointment
    public function create()
    {
        $query = "INSERT INTO " . $this->table_name . " 
                 (Pemail, Pphone, APPplace, APPdate, APPtime, APPreason, status) 
                 VALUES (:email, :phone, :place, :date, :time, :reason, 'Scheduled')";

        $stmt = $this->conn->prepare($query);

        // Sanitize input
        $this->Pemail = htmlspecialchars(strip_tags($this->Pemail));
        $this->Pphone = htmlspecialchars(strip_tags($this->Pphone));
        $this->APPplace = htmlspecialchars(strip_tags($this->APPplace));
        $this->APPdate = htmlspecialchars(strip_tags($this->APPdate));
        $this->APPtime = htmlspecialchars(strip_tags($this->APPtime));
        $this->APPreason = htmlspecialchars(strip_tags($this->APPreason));

        // Bind values
        $stmt->bindParam(":email", $this->Pemail);
        $stmt->bindParam(":phone", $this->Pphone);
        $stmt->bindParam(":place", $this->APPplace);
        $stmt->bindParam(":date", $this->APPdate);
        $stmt->bindParam(":time", $this->APPtime);
        $stmt->bindParam(":reason", $this->APPreason);

        return $stmt->execute();
    }

    // Update appointment
    public function update()
    {
        $query = "UPDATE " . $this->table_name . " 
                 SET Pemail = :email,
                     Pphone = :phone, 
                     APPplace = :place, 
                     APPdate = :date, 
                     APPtime = :time, 
                     APPreason = :reason,
                     status = :status
                 WHERE APPID = :id";

        $stmt = $this->conn->prepare($query);

        // Sanitize input
        $this->APPID = htmlspecialchars(strip_tags($this->APPID));
        $this->Pemail = htmlspecialchars(strip_tags($this->Pemail));
        $this->Pphone = htmlspecialchars(strip_tags($this->Pphone));
        $this->APPplace = htmlspecialchars(strip_tags($this->APPplace));
        $this->APPdate = htmlspecialchars(strip_tags($this->APPdate));
        $this->APPtime = htmlspecialchars(strip_tags($this->APPtime));
        $this->APPreason = htmlspecialchars(strip_tags($this->APPreason));
        $this->status = htmlspecialchars(strip_tags($this->status));

        // Bind values
        $stmt->bindParam(":id", $this->APPID);
        $stmt->bindParam(":email", $this->Pemail);
        $stmt->bindParam(":phone", $this->Pphone);
        $stmt->bindParam(":place", $this->APPplace);
        $stmt->bindParam(":date", $this->APPdate);
        $stmt->bindParam(":time", $this->APPtime);
        $stmt->bindParam(":reason", $this->APPreason);
        $stmt->bindParam(":status", $this->status);

        return $stmt->execute();
    }

    // Delete appointment
    public function delete()
    {
        $query = "DELETE FROM " . $this->table_name . " WHERE APPID = :id";

        $stmt = $this->conn->prepare($query);
        $this->APPID = htmlspecialchars(strip_tags($this->APPID));
        $stmt->bindParam(":id", $this->APPID);

        return $stmt->execute();
    }

    // Read all appointments
    public function readAll()
    {
        $query = "SELECT 
                     APPID,
                    Pemail,
                    Pphone,
                    APPplace,
                    APPdate,
                    APPtime,
                    APPreason,
                    status
                FROM " . $this->table_name . "
                ORDER BY APPdate DESC, APPtime DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt;
    }

    // Read single appointment
    public function readOne()
    {
        $query = "SELECT 
                    APPID,
                    Pemail,
                    Pphone,
                    APPplace,
                    APPdate,
                    APPtime,
                    APPreason,
                    status
                FROM " . $this->table_name . "
                WHERE APPID = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->APPID);
        $stmt->execute();

        return $stmt;
    }

    // In your Appointment class, add this method:
    public function getById($id)
    {
        $this->APPID = $id;
        $stmt = $this->readOne();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>