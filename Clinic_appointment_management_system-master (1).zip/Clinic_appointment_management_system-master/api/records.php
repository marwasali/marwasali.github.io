<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE");
header("Access-Control-Allow-Headers: Content-Type");

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../config/database.php";
require_once "../model/Record.php";

try {
    $db = (new Database())->getConnection();
    $record = new Record($db);
    
    $method = $_SERVER["REQUEST_METHOD"];
    
    if ($method === "GET") {
        $stmt = $record->getAll();
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($records === false) {
            echo json_encode(["error" => "Failed to fetch records", "details" => $stmt->errorInfo()]);
            http_response_code(500);
        } else {
            echo json_encode($records);
        }
    }
    
    elseif ($method === "POST") {
        $input = file_get_contents("php://input");
        $data = json_decode($input, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode(["success" => false, "error" => "Invalid JSON data", "details" => json_last_error_msg()]);
            http_response_code(400);
            exit;
        }
        
        if (!isset($data["patient_name"], $data["doctor_name"], $data["record_date"], $data["diagnosis"], $data["treatment"])) {
            echo json_encode(["success" => false, "error" => "Missing required fields"]);
            http_response_code(400);
            exit;
        }
        
        // Check if it's an update or insert
        if (isset($data["id"]) && !empty($data["id"]) && $data["id"] !== null) {
            $ok = $record->update([
                "id" => $data["id"],
                "patient" => $data["patient_name"],
                "doctor" => $data["doctor_name"],
                "date" => $data["record_date"],
                "diagnosis" => $data["diagnosis"],
                "treatment" => $data["treatment"]
            ]);
        } else {
            $ok = $record->create([
                "patient" => $data["patient_name"],
                "doctor" => $data["doctor_name"],
                "date" => $data["record_date"],
                "diagnosis" => $data["diagnosis"],
                "treatment" => $data["treatment"]
            ]);
        }
        
        echo json_encode(["success" => $ok, "message" => $ok ? "Operation successful" : "Operation failed"]);
    }
    
    elseif ($method === "DELETE") {
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        
        if (!$id) {
            echo json_encode(["success" => false, "error" => "No ID provided"]);
            http_response_code(400);
            exit;
        }
        
        $ok = $record->delete($id);
        echo json_encode(["success" => $ok, "message" => $ok ? "Record deleted" : "Delete failed"]);
    }
    
    else {
        echo json_encode(["error" => "Method not allowed"]);
        http_response_code(405);
    }
    
} catch (Exception $e) {
    echo json_encode([
        "success" => false, 
        "error" => "Server error", 
        "details" => $e->getMessage()
    ]);
    http_response_code(500);
}
?>