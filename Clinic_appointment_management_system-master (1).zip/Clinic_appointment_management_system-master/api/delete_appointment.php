
<?php
/*
// Database connection
$servername = "localhost";
$username = "root";  // Change if needed
$password = "";      // Change if needed
$dbname = "webdevproject"; // Change to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the appointment ID to delete
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    // Delete the appointment
    $sql = "DELETE FROM appointments WHERE APPID = $id";
    
    if ($conn->query($sql) === TRUE) {
        // Redirect back to appointments page
        header("Location: ../html/app.php");
        exit();
    } else {
        echo "Error deleting appointment: " . $conn->error;
    }
} else {
    echo "Invalid appointment ID";
}

$conn->close();
?>
*/

// Include the Database class
/*
require_once '../config/database.php';

// Get the appointment ID to delete
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Create Database instance and get PDO connection
        $database = new Database();
        $conn = $database->getConnection();
        
        // Prepare the DELETE statement using PDO
        $sql = "DELETE FROM book_app WHERE APPID = :id";
        $stmt = $conn->prepare($sql);
        
        // Bind the parameter
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        
        // Execute the statement
        if ($stmt->execute()) {
            // Redirect back to appointments page
            header("Location: ../html/app.php");
            exit();
        } else {
            echo "Error deleting appointment.";
        }
        
        // Close connection
        $conn = null;
        
    } catch(PDOException $exception) {
        echo "Error: " . $exception->getMessage();
    }
} else {
    echo "Invalid appointment ID";
}
?>
*/


// delete_appointment.php - SIMPLE VERSION
$host = "localhost";
$username = "root";
$password = "";
$dbname = "webdevproject";

// Get the appointment ID
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    // Create connection
    $conn = new mysqli($host, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Delete the appointment
    $sql = "DELETE FROM book_app WHERE APPID = $id";
    
    if ($conn->query($sql) === TRUE) {
        // Redirect back to appointments page
        header("Location: ../html/app.php");
        exit();
    } else {
        echo "Error deleting appointment: " . $conn->error;
    }
    
    $conn->close();
} else {
    echo "Invalid appointment ID";
}
?>