<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "clinic_db";

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Get department name from URL
if (!isset($_GET['name'])) die("No department selected.");

$depName = $_GET['name'];

// Fetch existing data
$sql = "SELECT * FROM departments WHERE DEPname=?";
$stmt = $connection->prepare($sql);
$stmt->bind_param("s", $depName);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) die("Department not found.");

$department = $result->fetch_assoc();

// Update if form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newName = $_POST['depName'];
    $depEmail = $_POST['depEmail'];
    $depPhone = $_POST['depPhone'];
    $depLocation = $_POST['depLocation'];
    $depHead = $_POST['depHead'];
    $depStaff = $_POST['depStaff'];

    $updateSql = "UPDATE departments SET DEPname=?, DEPemail=?, DEPphone=?, DEPlocation=?, DEPhead=?, DEPstaffcount=? WHERE DEPname=?";
    $updateStmt = $connection->prepare($updateSql);
    $updateStmt->bind_param("sssssis", $newName, $depEmail, $depPhone, $depLocation, $depHead, $depStaff, $depName);

    if ($updateStmt->execute()) {
        header("Location: departments.php");
        exit();
    } else {
        echo "Error: " . $updateStmt->error;
    }
}
$connection->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Department</title>
    <link rel="stylesheet" href="/clinic/css/mod.css">
</head>
<body>

<h1>Edit Department</h1>

<form method="POST">
    <label>
        Department Name:
        <input type="text" name="depName"
               value="<?php echo htmlspecialchars($department['DEPname']); ?>" required>
    </label><br><br>

    <label>
        Email:
        <input type="email" name="depEmail"
               value="<?php echo htmlspecialchars($department['DEPemail']); ?>" required>
    </label><br><br>

    <label>
        Phone:
        <input type="text" name="depPhone"
               value="<?php echo htmlspecialchars($department['DEPphone']); ?>" required>
    </label><br><br>

    <label>
        Location:
        <input type="text" name="depLocation"
               value="<?php echo htmlspecialchars($department['DEPlocation']); ?>" required>
    </label><br><br>

    <label>
        Head:
        <input type="text" name="depHead"
               value="<?php echo htmlspecialchars($department['DEPhead']); ?>" required>
    </label><br><br>

    <label>
        Staff Count:
        <input type="number" name="depStaff"
               value="<?php echo htmlspecialchars($department['DEPstaffcount']); ?>" required>
    </label><br><br>

    <button type="submit">Update Department</button>
</form>

</body>
</html>
