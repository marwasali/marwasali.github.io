<?php
header('Content-Type: application/json');

// Connect to database
include '../config/database.php';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
    exit;
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO feedback (FName, FEmail, FDepartment, FDeptRating, FDoctor, FDocRating, FMessage, FSubmittedAt) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
$stmt->bind_param(
    "sssssss",
    $input['FName'],
    $input['FEmail'],
    $input['FDepartment'],
    $input['FDeptRating'],
    $input['FDoctor'],
    $input['FDocRating'],
    $input['FMessage']
);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Feedback submitted successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to submit feedback']);
}

$stmt->close();
$conn->close();
?>

