<?php
// Add this to suppress deprecation warnings during development
error_reporting(E_ALL & ~E_DEPRECATED);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../model/Appointment.php';

$database = new Database();
$db = $database->getConnection();

$appointment = new Appointment($db);

// Check if we're getting a specific appointment or all appointments
$appointment_id = isset($_GET['id']) ? $_GET['id'] : (isset($data->APPID) ? $data->APPID : null);

if($appointment_id) {
    // Get single appointment
    $appointment->APPID = $appointment_id;
    $stmt = $appointment->readOne();
    $num = $stmt->rowCount();
    
    if($num > 0) {
        $appointment_arr = array();
        $appointment_arr["records"] = array();
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            
            $appointment_item = array(
                "APPID" => $APPID,
                "email" => $Pemail,
                "phone" => $Pphone,
                "place" => $APPplace,
                "date" => $APPdate,
                "time" => $APPtime,
                "reason" => $APPreason,
                "status" => $status
            );
            
            array_push($appointment_arr["records"], $appointment_item);
        }
        
        http_response_code(200);
        echo json_encode(array(
            "success" => true,
            "data" => $appointment_arr["records"]
        ));
    } else {
        http_response_code(404);
        echo json_encode(array(
            "success" => false,
            "message" => "Appointment not found."
        ));
    }
} else {
    // Get all appointments
    $stmt = $appointment->readAll();
    $num = $stmt->rowCount();
    
    if($num > 0) {
        $appointment_arr = array();
        $appointment_arr["records"] = array();
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            
            $appointment_item = array(
                "APPID" => $APPID,
                "email" => $Pemail,
                "phone" => $Pphone,
                "place" => $APPplace,
                "date" => $APPdate,
                "time" => $APPtime,
                "reason" => $APPreason,
                "status" => $status
            );
            
            array_push($appointment_arr["records"], $appointment_item);
        }
        
        http_response_code(200);
        echo json_encode(array(
            "success" => true,
            "count" => $num,
            "data" => $appointment_arr["records"]
        ));
    } else {
        http_response_code(404);
        echo json_encode(array(
            "success" => true,
            "count" => 0,
            "message" => "No appointments found.",
            "data" => array()
        ));
    }
}
?>