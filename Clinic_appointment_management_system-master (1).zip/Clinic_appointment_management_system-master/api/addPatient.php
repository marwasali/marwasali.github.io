<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
include '../config/database.php';

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    echo json_encode(["status"=>"error","message"=>"DB connection failed: " . mysqli_connect_error()]);
    exit;
}

// Check if POST data exists
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status"=>"error","message"=>"Invalid request method"]);
    exit;
}

// Read POST data safely
$Pfirstname = mysqli_real_escape_string($conn, $_POST['Pfirstname']);
$Plastname  = mysqli_real_escape_string($conn, $_POST['Plastname']);
$Pemail     = mysqli_real_escape_string($conn, $_POST['Pemail']);
$Pphone     = mysqli_real_escape_string($conn, $_POST['Pphone']);
$Paddress   = mysqli_real_escape_string($conn, $_POST['Paddress']);
$Pdate_of_birth = mysqli_real_escape_string($conn, $_POST['Pdate_of_birth']);
$Pgender    = mysqli_real_escape_string($conn, $_POST['Pgender']);

// Insert into database
$sql = "INSERT INTO patients (Pfirstname, Plastname, Pemail, Pphone, Paddress, Pdate_of_birth, Pgender)
        VALUES ('$Pfirstname', '$Plastname', '$Pemail', '$Pphone', '$Paddress', '$Pdate_of_birth', '$Pgender')";

if (mysqli_query($conn, $sql)) {
    echo json_encode(["status"=>"success","message"=>"Patient added successfully"]);
} else {
    echo json_encode(["status"=>"error","message"=>"Failed to add patient: " . mysqli_error($conn)]);
}

mysqli_close($conn);
?>
