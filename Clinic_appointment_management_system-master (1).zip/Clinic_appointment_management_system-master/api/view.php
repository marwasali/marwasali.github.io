<?php
include '../config/database.php';


// Check if 'id' is passed in URL
if (!isset($_GET['id'])) {
    echo "No patient ID provided!";
    exit;
}

$patient_id = $_GET['id'];

// Fetch patient details from database using MySQLi
$sql = "SELECT * FROM patients WHERE PID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Patient not found!";
    exit;
}

$patient = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Details</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 50%; }
        td, th { border: 1px solid #ddd; padding: 8px; }
        th { background-color: #f2f2f2; text-align: left; }
        a { text-decoration: none; color: blue; }
    </style>
</head>
<body>
    <h2>Patient Details</h2>
    <table>
        <tr><th>ID</th><td><?= htmlspecialchars($patient['PID']); ?></td></tr>
        <tr><th>First Name</th><td><?= htmlspecialchars($patient['Pfirstname']); ?></td></tr>
        <tr><th>Last Name</th><td><?= htmlspecialchars($patient['Plastname']); ?></td></tr>
        <tr><th>Email</th><td><?= htmlspecialchars($patient['Pemail']); ?></td></tr>
        <tr><th>Gender</th><td><?= htmlspecialchars($patient['Pgender']); ?></td></tr>
        <tr><th>Date of Birth</th><td><?= htmlspecialchars($patient['Pdate_of_birth']); ?></td></tr>
        <tr><th>Phone</th><td><?= htmlspecialchars($patient['Pphone']); ?></td></tr>
        <tr><th>Address</th><td><?= htmlspecialchars($patient['Paddress']); ?></td></tr>
        <tr><th>Doctor ID</th><td><?= htmlspecialchars($patient['DOCTORID']); ?></td></tr>
        <tr><th>Department ID</th><td><?= htmlspecialchars($patient['DEPID']); ?></td></tr>
    </table>
    <br>
    <a href="Patient.html">Back to Patients List</a>
</body>

</html>

