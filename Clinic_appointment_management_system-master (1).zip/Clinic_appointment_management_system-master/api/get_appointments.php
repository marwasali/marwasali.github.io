<?php
// Database connection
$servername = "localhost";
$username = "root";  // Change if needed
$password = "";      // Change if needed
$dbname = "webdevproject"; // Change to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo "<tr><td colspan='8' style='color: red; text-align: center;'>Database connection failed: " . $conn->connect_error . "</td></tr>";
    exit();
}

// Set connection charset
$conn->set_charset("utf8mb4");

// Query to fetch appointments
$sql = "SELECT APPID, Email, Phone, APPlace, APDate, APTime, APPreason, status 
        FROM appointments 
        ORDER BY APDate DESC, APTime DESC";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        // Extract name from email
        $patient_name = "Unknown Patient";
        if (!empty($row["Email"])) {
            $email_parts = explode("@", $row["Email"]);
            $username = $email_parts[0];
            $patient_name = ucwords(str_replace(['.', '_', '-'], ' ', $username));
        }
        
        // Format date
        $formatted_date = "Not Set";
        if (!empty($row["APDate"]) && $row["APDate"] != "0000-00-00") {
            $date = new DateTime($row["APDate"]);
            $formatted_date = $date->format('M d, Y');
        }
        
        // Format time
        $formatted_time = "Not Set";
        if (!empty($row["APTime"]) && $row["APTime"] != "00:00:00") {
            $time = new DateTime($row["APTime"]);
            $formatted_time = $time->format('h:i A');
        }
        
        // Determine status class
        $status_class = "status-scheduled";
        $status = ucfirst($row["status"] ?: "scheduled");
        
        switch(strtolower($status)) {
            case 'confirmed':
                $status_class = "status-confirmed";
                break;
            case 'cancelled':
                $status_class = "status-cancelled";
                break;
            case 'completed':
                $status_class = "status-completed";
                break;
            default:
                $status_class = "status-scheduled";
        }
        
        // Display the row
        echo "<tr>";
        echo "<td>";
        echo "<div><strong>" . htmlspecialchars($patient_name) . "</strong></div>";
        echo "<small style='color: #666;'>" . htmlspecialchars($row["Email"]) . "</small><br>";
        echo "<small style='color: #666;'>" . htmlspecialchars($row["Phone"]) . "</small>";
        echo "</td>";
        echo "<td>";
        echo "<div><strong>Dr. Smith</strong></div>";
        echo "<small style='color: #666;'>General Department</small>";
        echo "</td>";
        echo "<td>" . htmlspecialchars($formatted_date) . "</td>";
        echo "<td>" . htmlspecialchars($formatted_time) . "</td>";
        echo "<td>" . htmlspecialchars($row["APPlace"]) . "</td>";
        echo "<td><span class='" . $status_class . "'>" . htmlspecialchars($status) . "</span></td>";
        echo "<td>" . htmlspecialchars($row["APPreason"]) . "</td>";
        echo "<td>";
        echo "<i class='fas fa-edit edit-icon' onclick=\"editAppointment(" . $row["APPID"] . ")\" title='Edit appointment'></i>";
        echo "<i class='fas fa-trash delete-icon' onclick=\"deleteAppointment(" . $row["APPID"] . ")\" title='Delete appointment'></i>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='8' style='text-align: center; padding: 40px; color: #666;'>No appointments found.</td></tr>";
}

// Close connection
$conn->close();
?>