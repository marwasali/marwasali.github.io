<?php
session_start();

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the database connection file
require_once "../config/db.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Get doctor ID from hidden field
    $doctorId = mysqli_real_escape_string($conn, $_POST['doctorId'] ?? '');
    
    // Validate doctor ID
    if (empty($doctorId)) {
        $_SESSION['message'] = 'Invalid doctor ID';
        $_SESSION['message_type'] = 'error';
        header("Location: ../html/doctors.php");
        exit();
    }
    
    // Check if doctor exists
    $checkQuery = "SELECT DOCTORID FROM doctors WHERE DOCTORID = '$doctorId'";
    $checkResult = mysqli_query($conn, $checkQuery);
    if (mysqli_num_rows($checkResult) == 0) {
        $_SESSION['message'] = 'Doctor not found';
        $_SESSION['message_type'] = 'error';
        header("Location: ../html/doctors.php");
        exit();
    }
    
    // Extract and sanitize form data
    $firstName = mysqli_real_escape_string($conn, $_POST['firstName'] ?? '');
    $lastName = mysqli_real_escape_string($conn, $_POST['lastName'] ?? '');
    $age = isset($_POST['age']) ? intval($_POST['age']) : 0;
    $gender = mysqli_real_escape_string($conn, $_POST['gender'] ?? '');
    $email = mysqli_real_escape_string($conn, $_POST['email'] ?? '');
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile'] ?? '');
    $phone = isset($_POST['phone']) && !empty($_POST['phone']) ? mysqli_real_escape_string($conn, $_POST['phone']) : null;
    $maritalStatus = isset($_POST['maritalStatus']) && !empty($_POST['maritalStatus']) ? mysqli_real_escape_string($conn, $_POST['maritalStatus']) : null;
    $experience = isset($_POST['experience']) && !empty($_POST['experience']) ? intval($_POST['experience']) : 0;
    $bio = isset($_POST['bio']) && !empty($_POST['bio']) ? mysqli_real_escape_string($conn, $_POST['bio']) : null;
    $rating = isset($_POST['rating']) && !empty($_POST['rating']) ? floatval($_POST['rating']) : 0;
    $bloodGroup = isset($_POST['bloodGroup']) && !empty($_POST['bloodGroup']) ? mysqli_real_escape_string($conn, $_POST['bloodGroup']) : null;
    $status = isset($_POST['status']) ? mysqli_real_escape_string($conn, $_POST['status']) : 'on';
    
    // Validate required fields
    if (empty($firstName) || empty($lastName) || empty($email)) {
        $_SESSION['message'] = 'Please fill all required fields (First Name, Last Name, Email)';
        $_SESSION['message_type'] = 'error';
        header("Location: ../html/edit-doctor.php?id=$doctorId");
        exit();
    }
    
    // Check if at least one specialty is selected
    if (empty($_POST['specialties']) || !is_array($_POST['specialties'])) {
        $_SESSION['message'] = 'Please select at least one specialty';
        $_SESSION['message_type'] = 'error';
        header("Location: ../html/edit-doctor.php?id=$doctorId");
        exit();
    }
    
    // Handle file upload
    $photoPath = null;
    if (isset($_FILES['profilePhoto']) && $_FILES['profilePhoto']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/doctors/';
        
        // Create directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileExtension = strtolower(pathinfo($_FILES['profilePhoto']['name'], PATHINFO_EXTENSION));
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($fileExtension, $allowedExtensions)) {
            $newFileName = 'doctor_' . $doctorId . '_' . time() . '.' . $fileExtension;
            $targetPath = $uploadDir . $newFileName;
            
            if ($_FILES['profilePhoto']['size'] <= 5 * 1024 * 1024) {
                if (move_uploaded_file($_FILES['profilePhoto']['tmp_name'], $targetPath)) {
                    $photoPath = 'uploads/doctors/' . $newFileName;
                    
                    // Delete old photo if exists
                    $oldPhotoQuery = "SELECT Photo FROM doctors WHERE DOCTORID = '$doctorId'";
                    $oldPhotoResult = mysqli_query($conn, $oldPhotoQuery);
                    if ($oldPhotoResult && $oldPhoto = mysqli_fetch_assoc($oldPhotoResult)) {
                        if (!empty($oldPhoto['Photo']) && file_exists('../' . $oldPhoto['Photo'])) {
                            unlink('../' . $oldPhoto['Photo']);
                        }
                    }
                }
            }
        }
    }

    // Get existing columns in doctors table
    $columnsResult = mysqli_query($conn, "DESCRIBE doctors");
    $existingColumns = [];
    while ($row = mysqli_fetch_assoc($columnsResult)) {
        $existingColumns[] = $row['Field'];
    }
    
    // Build the UPDATE query with only existing columns
    $updateData = [
        'FirstName' => "'$firstName'",
        'LastName' => "'$lastName'",
        'Age' => $age,
        'Gender' => "'$gender'",
        'Email' => "'$email'",
        'Mobile' => "'$mobile'",
        'Status' => "'$status'"
    ];
    
    // Add optional fields if they exist in the table
    if ($phone !== null && in_array('Phone', $existingColumns)) {
        $updateData['Phone'] = "'$phone'";
    }
    if ($maritalStatus !== null && in_array('MaritalStatus', $existingColumns)) {
        $updateData['MaritalStatus'] = "'$maritalStatus'";
    }
    if ($experience > 0 && in_array('Experience', $existingColumns)) {
        $updateData['Experience'] = $experience;
    }
    if ($bio !== null && in_array('Bio', $existingColumns)) {
        $updateData['Bio'] = "'$bio'";
    }
    if ($rating > 0 && in_array('Rating', $existingColumns)) {
        $updateData['Rating'] = $rating;
    }
    if ($bloodGroup !== null && in_array('BloodGroup', $existingColumns)) {
        $updateData['BloodGroup'] = "'$bloodGroup'";
    }
    if ($photoPath !== null && in_array('Photo', $existingColumns)) {
        $updateData['Photo'] = "'$photoPath'";
    }
    
    // Check for additional optional fields
    $optionalFields = [
        'Qualification' => isset($_POST['qualification']) && !empty($_POST['qualification']) ? "'" . mysqli_real_escape_string($conn, $_POST['qualification']) . "'" : null,
        'Designation' => isset($_POST['designation']) && !empty($_POST['designation']) ? "'" . mysqli_real_escape_string($conn, $_POST['designation']) . "'" : null,
        'Address' => isset($_POST['address']) && !empty($_POST['address']) ? "'" . mysqli_real_escape_string($conn, $_POST['address']) . "'" : null,
        'Wilaya' => isset($_POST['wilaya']) && !empty($_POST['wilaya']) ? "'" . mysqli_real_escape_string($conn, $_POST['wilaya']) . "'" : null,
        'Daira' => isset($_POST['daira']) && !empty($_POST['daira']) ? "'" . mysqli_real_escape_string($conn, $_POST['daira']) . "'" : null,
        'PostalCode' => isset($_POST['postalCode']) && !empty($_POST['postalCode']) ? "'" . mysqli_real_escape_string($conn, $_POST['postalCode']) . "'" : null,
        'Username' => isset($_POST['username']) && !empty($_POST['username']) ? "'" . mysqli_real_escape_string($conn, $_POST['username']) . "'" : null,
    ];
    
    // Add password if provided and matches confirmation
    if (!empty($_POST['password']) && in_array('Password', $existingColumns)) {
        if ($_POST['password'] === $_POST['confirmPassword']) {
            $hashedPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $optionalFields['Password'] = "'$hashedPassword'";
        } else {
            $_SESSION['message'] = 'Passwords do not match';
            $_SESSION['message_type'] = 'error';
            header("Location: ../html/edit-doctor.php?id=$doctorId");
            exit();
        }
    }
    
    // Add only fields that exist in the table
    foreach ($optionalFields as $field => $value) {
        if ($value !== null && in_array($field, $existingColumns)) {
            $updateData[$field] = $value;
        }
    }

    // Build and execute the UPDATE query
    $updatePairs = [];
    foreach ($updateData as $field => $value) {
        $updatePairs[] = "$field = $value";
    }
    $updateString = implode(', ', $updatePairs);
    $sql_doctor = "UPDATE doctors SET $updateString WHERE DOCTORID = '$doctorId'";

    if (mysqli_query($conn, $sql_doctor)) {
        // Delete existing schedule
        $delete_schedule = "DELETE FROM doctor_schedule WHERE DoctorID = '$doctorId'";
        mysqli_query($conn, $delete_schedule);
        
        // Insert updated schedule
        $days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
        foreach ($days as $day) {
            $fromField = $day . 'From';
            $toField = $day . 'To';
            
            if (!empty($_POST[$fromField]) && !empty($_POST[$toField])) {
                $startTime = mysqli_real_escape_string($conn, $_POST[$fromField]);
                $endTime = mysqli_real_escape_string($conn, $_POST[$toField]);
                
                $sql_schedule = "INSERT INTO doctor_schedule (DoctorID, DayOfWeek, StartTime, EndTime)
                                VALUES ('$doctorId', '$day', '$startTime', '$endTime')";
                
                mysqli_query($conn, $sql_schedule);
            }
        }

        // Delete existing specialties
        $delete_specialties = "DELETE FROM doc_specialty WHERE DoctorID = '$doctorId'";
        mysqli_query($conn, $delete_specialties);
        
        // Insert updated specialties
        if (!empty($_POST['specialties']) && is_array($_POST['specialties'])) {
            foreach ($_POST['specialties'] as $specialtyId) {
                $specialtyId = intval($specialtyId);
                $sql_specialty = "INSERT INTO doc_specialty (DoctorID, SpecialtyID)
                                  VALUES ('$doctorId', $specialtyId)";
                
                mysqli_query($conn, $sql_specialty);
            }
        }

        // Success
        $_SESSION['message'] = 'Doctor updated successfully!';
        $_SESSION['message_type'] = 'success';
        header("Location: ../html/doctors.php");
        exit();
        
    } else {
        // Handle error
        $_SESSION['message'] = 'Error updating doctor: ' . mysqli_error($conn);
        $_SESSION['message_type'] = 'error';
        error_log("Doctor update error: " . mysqli_error($conn));
        header("Location: ../html/edit-doctor.php?id=$doctorId");
        exit();
    }

    mysqli_close($conn);
    
} else {
    header("Location: ../html/doctors.php");
    exit();
}
?>
