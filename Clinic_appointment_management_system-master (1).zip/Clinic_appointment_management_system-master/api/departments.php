<?php
// ===== DATABASE CONNECTION =====
$conn = new mysqli("localhost", "root", "", "clinic_db");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all departments
$sql = "SELECT * FROM departments";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Department List | HopeCare</title>
    <link rel="stylesheet" href="css/departments.css" />
    <link rel="stylesheet" href="css/add-departments.css"/>
    <link rel="stylesheet" href="/clinic/css/dep.css"/>
    <link rel="stylesheet" href="/clinic/css/add.css"/>
    <link rel="stylesheet" href="../css/modifyDep.css"/>
</head>

<body>

    <!-- NAVBAR -->
    <nav>
        <div class="nav-left">
            <div class="logo">
                <div class="logo-icon">+</div>
                <span>HopeCare</span>
            </div>
            <ul class="nav-links">
                <li><a href="index.html">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle">Management</a>
                    <div class="dropdown-menu">
                        <a href="../html/doctors.html">Doctors</a>
                        <a href="../html/patient.html">Patients</a>
                        <a href="../departments.php">Departments</a>
                        <a href="../html/records.html">Medical Records</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <main class="main-content">
        <h1>Department List</h1>

        <div class="actions">
            <a class="logout-btn" href="/clinic/php/add.php">+ Add Department</a>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Department Info</th>
                        <th>Phone</th>
                        <th>Location</th>
                        <th>Head</th>
                        <th>Staff</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                    ?>
                            <tr>
                                <td>
                                    <div class="dep-info">
                                        <h4><?php echo $row['DEPname']; ?></h4>
                                        <p><?php echo $row['DEPemail']; ?></p>
                                    </div>
                                </td>
                                <td><?php echo $row['DEPphone']; ?></td>
                                <td><?php echo $row['DEPlocation']; ?></td>
                                <td><?php echo $row['DEPhead']; ?></td>
                                <td><?php echo $row['DEPstaffcount']; ?></td>
                                <td class="actions-btns">

                                    <a class="btn-icon edit" href="/clinic/php/edit.php?name=<?php echo urlencode ($row['DEPname']); ?>">✏️</a> 
                
                                   <a class="btn-icon delete"
                                        href="/clinic/delete.php?name=<?php echo urlencode ($row['DEPname']); ?>"
                                        onclick="return confirm('Delete this department?')">🗑️</a> 
                                </td>
                            </tr>
                    <?php
                        }
                    } else {
                        echo "<tr><td colspan='6'>No departments found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>

</body>

</html>

<?php
$conn->close();
?>
