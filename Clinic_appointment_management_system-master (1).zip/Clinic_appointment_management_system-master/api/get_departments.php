<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$query = "SELECT DEPID as id, DEPName as name FROM departments ORDER BY DEPName";
$stmt = $db->prepare($query);
$stmt->execute();

$num = $stmt->rowCount();

if($num > 0) {
    $depts_arr = array();
    $depts_arr["success"] = true;
    $depts_arr["data"] = array();
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        
        $dept_item = array(
            "id" => $id,
            "name" => $name
        );
        
        array_push($depts_arr["data"], $dept_item);
    }
    
    echo json_encode($depts_arr);
} else {
    echo json_encode(array(
        "success" => false,
        "data" => [],
        "message" => "No departments found."
    ));
}
?>