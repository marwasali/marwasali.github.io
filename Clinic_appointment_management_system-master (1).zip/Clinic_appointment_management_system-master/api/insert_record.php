<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $record_date = $_POST['record_date'];
    $diagnosis = $_POST['diagnosis'];
    $treatment = $_POST['treatment'];
    $patient_name = $_POST['patient_name'];
    $doctor_name = $_POST['doctor_name'];

    $sql = "INSERT INTO records (record_date, diagnosis, treatment, patient_name, doctor_name)
            VALUES ('$record_date', '$diagnosis', '$treatment', '$patient_name', '$doctor_name')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["success" => true, "message" => "Record added successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Error: " . $sql . "<br>" . $conn->error]);
    }
}

$conn->close();
?>
