<?php
header('Content-Type: application/json');

include '../config/database.php';

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    echo json_encode(["status"=>"error","message"=>"DB connection failed"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status"=>"error","message"=>"Invalid request method"]);
    exit;
}

if (!isset($_POST['PID'])) {
    echo json_encode(["status"=>"error","message"=>"No patient ID provided"]);
    exit;
}

$PID        = intval($_POST['PID']);
$Pfirstname = mysqli_real_escape_string($conn, $_POST['Pfirstname']);
$Plastname  = mysqli_real_escape_string($conn, $_POST['Plastname']);
$Pemail     = mysqli_real_escape_string($conn, $_POST['Pemail']);
$Pphone     = mysqli_real_escape_string($conn, $_POST['Pphone']);
$Paddress   = mysqli_real_escape_string($conn, $_POST['Paddress']);
$Pdate_of_birth = mysqli_real_escape_string($conn, $_POST['Pdate_of_birth']);
$Pgender    = mysqli_real_escape_string($conn, $_POST['Pgender']);

$sql = "UPDATE patients SET 
        Pfirstname='$Pfirstname',
        Plastname='$Plastname',
        Pemail='$Pemail',
        Pphone='$Pphone',
        Paddress='$Paddress',
        Pdate_of_birth='$Pdate_of_birth',
        Pgender='$Pgender'
        WHERE PID=$PID";

if (mysqli_query($conn, $sql)) {
    echo json_encode(["status"=>"success","message"=>"Patient updated successfully"]);
} else {
    echo json_encode(["status"=>"error","message"=>"Failed to update patient: ".mysqli_error($conn)]);
}

mysqli_close($conn);
?>

