<?php

// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$database = "clinic_db"; 

$connection = new mysqli($servername, $username, $password, $database);
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $depName = $_POST['depName'];
    $depEmail = $_POST['depEmail'];
    $depPhone = $_POST['depPhone'];
    $depLocation = $_POST['depLocation'];
    $depHead = $_POST['depHead'];
    $depStaff = $_POST['depStaff'];

    // Prepare the SQL query
    $sql = "INSERT INTO departments (DEPname, DEPemail, DEPphone, DEPlocation, DEPhead, DEPstaffcount)
            VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $connection->prepare($sql);
    $stmt->bind_param("sssssi", $depName, $depEmail, $depPhone, $depLocation, $depHead, $depStaff);

    // Execute query and check
    if ($stmt->execute()) {
        // Redirect back to departments list after adding
        header("Location: departments.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$connection->close();
?>

<!-- HTML Form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Department | HopeCare</title>
    <link rel="stylesheet" href="/clinic/css/add.css"/>
</head>
<body>
    <h1>Add Department</h1>
    <form method="POST" action="">
        <label>Department Name: <input type="text" name="depName" required></label><br><br>
        <label>Email: <input type="email" name="depEmail" required></label><br><br>
        <label>Phone: <input type="text" name="depPhone" required></label><br><br>
        <label>Location: <input type="text" name="depLocation" required></label><br><br>
        <label>Head of Department: <input type="text" name="depHead" required></label><br><br>
        <label>Staff Count: <input type="number" name="depStaff" required></label><br><br>
        <button type="submit">Add Department</button>
    </form>
</body>
</html>
