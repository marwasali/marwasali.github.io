<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$query = "SELECT DOCTORID as id, CONCAT(FirstName, ' ', LastName) as name, 
                 Designation as department 
          FROM doctors 
          WHERE Status = 'on'
          ORDER BY FirstName";
$stmt = $db->prepare($query);
$stmt->execute();

$num = $stmt->rowCount();

if($num > 0) {
    $doctors_arr = array();
    $doctors_arr["success"] = true;
    $doctors_arr["data"] = array();
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        extract($row);
        
        $doctor_item = array(
            "id" => $id,
            "name" => $name,
            "department" => $department
        );
        
        array_push($doctors_arr["data"], $doctor_item);
    }
    
    echo json_encode($doctors_arr);
} else {
    echo json_encode(array(
        "success" => false,
        "data" => [],
        "message" => "No doctors found."
    ));
}
?>