<?php
// deletePatient.php
header('Content-Type: application/json');

include '../config/database.php';

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    echo json_encode(["status"=>"error","message"=>"DB connection failed"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !isset($_GET['id'])) {
    echo json_encode(["status"=>"error","message"=>"Invalid request"]);
    exit;
}

$id = intval($_GET['id']);

// Delete patient
$sql = "DELETE FROM patients WHERE PID = $id";
if (mysqli_query($conn, $sql)) {
    echo json_encode(["status"=>"success","message"=>"Patient deleted successfully"]);
} else {
    echo json_encode(["status"=>"error","message"=>"Failed to delete patient: " . mysqli_error($conn)]);
}

mysqli_close($conn);
?>

