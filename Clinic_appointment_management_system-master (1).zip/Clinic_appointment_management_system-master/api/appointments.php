<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set headers for CORS and JSON response
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database configuration
$servername = "localhost";
$username = "root";  // Change if needed
$password = "";      // Change if needed
$dbname = "hospital_db"; // Change to your database name

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed: " . $conn->connect_error,
        "data" => []
    ]);
    exit();
}

// Set connection charset
$conn->set_charset("utf8mb4");

// Handle different HTTP methods
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        handleGetRequest($conn);
        break;
    case 'DELETE':
        handleDeleteRequest($conn);
        break;
    case 'POST':
        handlePostRequest($conn);
        break;
    case 'PUT':
        handlePutRequest($conn);
        break;
    default:
        http_response_code(405);
        echo json_encode([
            "success" => false,
            "message" => "Method not allowed",
            "data" => []
        ]);
        break;
}

// Function to handle GET requests (fetch appointments)
function handleGetRequest($conn) {
    // Using your exact column names from the database
    $sql = "SELECT 
                APPID,
                Email,
                Phone,
                APPlace,
                APDate,
                APTime,
                APPreason,
                status
            FROM appointments
            ORDER BY APDate DESC, APTime DESC";
    
    $result = $conn->query($sql);
    
    if ($result) {
        $appointments = [];
        while ($row = $result->fetch_assoc()) {
            // Format the appointment data using your exact column names
            $appointment = [
                'id' => $row['APPID'],
                'patient_email' => $row['Email'],
                'patient_phone' => $row['Phone'],
                'place' => $row['APPlace'],
                'appointment_date' => formatDate($row['APDate']),
                'appointment_time' => formatTime($row['APTime']),
                'reason' => $row['APPreason'] ?: 'General Checkup',
                'status' => ucfirst($row['status'] ?: 'scheduled'),
                'patient_name' => extractNameFromEmail($row['Email']),
                'doctor_name' => 'Dr. Smith', // Default or from another table
                'department' => 'General',    // Default or from another table
                'raw_date' => $row['APDate'],
                'raw_time' => $row['APTime']
            ];
            
            $appointments[] = $appointment;
        }
        
        echo json_encode([
            "success" => true,
            "message" => "Appointments fetched successfully",
            "data" => $appointments,
            "count" => count($appointments)
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Error fetching appointments: " . $conn->error,
            "data" => []
        ]);
    }
}

// Function to handle DELETE requests
function handleDeleteRequest($conn) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = isset($input['id']) ? intval($input['id']) : (isset($_GET['id']) ? intval($_GET['id']) : 0);
    
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "Valid appointment ID is required"
        ]);
        return;
    }
    
    // Check if appointment exists using APPID
    $checkSql = "SELECT APPID FROM appointments WHERE APPID = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("i", $id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows === 0) {
        http_response_code(404);
        echo json_encode([
            "success" => false,
            "message" => "Appointment not found"
        ]);
        return;
    }
    
    // Delete the appointment
    $deleteSql = "DELETE FROM appointments WHERE APPID = ?";
    $deleteStmt = $conn->prepare($deleteSql);
    $deleteStmt->bind_param("i", $id);
    
    if ($deleteStmt->execute()) {
        echo json_encode([
            "success" => true,
            "message" => "Appointment deleted successfully"
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Error deleting appointment: " . $conn->error
        ]);
    }
}

// Function to handle POST requests (create new appointment)
function handlePostRequest($conn) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Required fields using your exact column names
    $required = ['Email', 'APDate', 'APTime'];
    foreach ($required as $field) {
        if (!isset($input[$field]) || empty($input[$field])) {
            http_response_code(400);
            echo json_encode([
                "success" => false,
                "message" => "Missing required field: $field"
            ]);
            return;
        }
    }
    
    // Using exact column names from your database
    $email = $conn->real_escape_string($input['Email']);
    $phone = isset($input['Phone']) ? $conn->real_escape_string($input['Phone']) : '';
    $place = isset($input['APPlace']) ? $conn->real_escape_string($input['APPlace']) : 'Main Clinic';
    $date = $conn->real_escape_string($input['APDate']);
    $time = $conn->real_escape_string($input['APTime']);
    $reason = isset($input['APPreason']) ? $conn->real_escape_string($input['APPreason']) : 'General Checkup';
    $status = isset($input['status']) ? $conn->real_escape_string($input['status']) : 'scheduled';
    
    $sql = "INSERT INTO appointments (Email, Phone, APPlace, APDate, APTime, APPreason, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $email, $phone, $place, $date, $time, $reason, $status);
    
    if ($stmt->execute()) {
        echo json_encode([
            "success" => true,
            "message" => "Appointment created successfully",
            "id" => $stmt->insert_id
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Error creating appointment: " . $stmt->error
        ]);
    }
}

// Function to handle PUT requests (update appointment)
function handlePutRequest($conn) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['id']) || $input['id'] <= 0) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "Valid appointment ID is required"
        ]);
        return;
    }
    
    $id = intval($input['id']);
    
    // Build dynamic update query using your exact column names
    $updates = [];
    $params = [];
    $types = "";
    
    $fields = [
        'Email' => 's',
        'Phone' => 's',
        'APPlace' => 's',
        'APDate' => 's',
        'APTime' => 's',
        'APPreason' => 's',
        'status' => 's'
    ];
    
    foreach ($fields as $field => $type) {
        if (isset($input[$field])) {
            $updates[] = "$field = ?";
            $params[] = $input[$field];
            $types .= $type;
        }
    }
    
    if (empty($updates)) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "No fields to update"
        ]);
        return;
    }
    
    $params[] = $id;
    $types .= 'i';
    
    $sql = "UPDATE appointments SET " . implode(', ', $updates) . " WHERE APPID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    
    if ($stmt->execute()) {
        echo json_encode([
            "success" => true,
            "message" => "Appointment updated successfully"
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Error updating appointment: " . $stmt->error
        ]);
    }
}

// Helper function to extract name from email
function extractNameFromEmail($email) {
    if (empty($email)) return 'Unknown Patient';
    
    // Extract username part before @
    $username = strtok($email, '@');
    
    // Convert to title case (john.doe -> John Doe)
    $username = str_replace(['.', '_', '-'], ' ', $username);
    $username = ucwords($username);
    
    return $username ?: 'Unknown Patient';
}

// Helper function to format date
function formatDate($dateString) {
    if (!$dateString || $dateString == '0000-00-00' || $dateString == '') return 'Not Set';
    $date = new DateTime($dateString);
    return $date->format('M d, Y');
}

// Helper function to format time
function formatTime($timeString) {
    if (!$timeString || $timeString == '00:00:00' || $timeString == '') return 'Not Set';
    $time = new DateTime($timeString);
    return $time->format('h:i A');
}

// Close database connection
$conn->close();
?>