<?php
header('Content-Type: application/json');

include '../config/database.php';

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) { echo json_encode(null); exit; }

if (!isset($_GET['id'])) { echo json_encode(null); exit; }

$pid = intval($_GET['id']);
$sql = "SELECT * FROM patients WHERE PID=$pid LIMIT 1";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

echo json_encode($row);
mysqli_close($conn);
?>

