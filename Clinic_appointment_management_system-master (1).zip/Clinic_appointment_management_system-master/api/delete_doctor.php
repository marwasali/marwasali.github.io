<?php
require_once "../config/db.php";

if (!isset($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'Doctor ID not provided']);
    exit();
}

$doctorId = mysqli_real_escape_string($conn, $_GET['id']);

// Delete doctor
$sql_delete = "DELETE FROM doctors WHERE DOCTORID = '$doctorId'";
if (mysqli_query($conn, $sql_delete)) {
    echo json_encode(['success' => true, 'message' => 'Doctor deleted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error deleting doctor']);
}
?>
