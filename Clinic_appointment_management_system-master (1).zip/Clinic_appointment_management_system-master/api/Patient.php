<?php
// displayPatients.php
header("Content-Type: application/json; charset=UTF-8");

// Database configuration
include '../config/database.php';

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed: " . $conn->connect_error,
        "data" => []
    ]);
    exit();
}

// Set charset
$conn->set_charset("utf8mb4");

// Fetch all patients
$sql = "SELECT PID, Pfirstname, Plastname, Pemail, Pphone, Paddress, Pdate_of_birth, Pgender FROM patients ORDER BY PID DESC";
$result = $conn->query($sql);

$patients = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $patients[] = $row;
    }
    echo json_encode([
        "success" => true,
        "message" => "Patients fetched successfully",
        "data" => $patients,
        "count" => count($patients)
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error fetching patients: " . $conn->error,
        "data" => []
    ]);
}

// Close connection
$conn->close();
?>

