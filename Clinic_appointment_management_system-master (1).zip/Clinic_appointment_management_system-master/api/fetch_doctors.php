<?php
require_once "../config/db.php";

// Fetch all doctors with their specialties
$sql_doctors = "SELECT d.*, 
                GROUP_CONCAT(s.Name SEPARATOR ', ') as Specialties
                FROM doctors d
                LEFT JOIN doc_specialty ds ON d.DOCTORID = ds.DoctorID
                LEFT JOIN specialties s ON ds.SpecialtyID = s.SpecialtyID
                GROUP BY d.DOCTORID
                ORDER BY d.FirstName, d.LastName";

$result_doctors = mysqli_query($conn, $sql_doctors);

if (!$result_doctors) {
    // If there's an error, return error message
    header('Content-Type: application/json');
    echo json_encode(['error' => mysqli_error($conn)]);
    exit();
}

$doctors = [];
while ($row = mysqli_fetch_assoc($result_doctors)) {
    // If no specialties, set to empty string or N/A
    if (empty($row['Specialties'])) {
        $row['Specialties'] = 'N/A';
    }
    $doctors[] = $row;
}

// Return doctors as JSON
header('Content-Type: application/json');
echo json_encode($doctors);
?>
