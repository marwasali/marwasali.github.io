<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../model/Appointment.php';

$database = new Database();
$db = $database->getConnection();

$appointment = new Appointment($db);

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->APPID)) {
    $appointment->APPID = $data->APPID;
    
    if($appointment->delete()) {
        http_response_code(200);
        echo json_encode(array(
            "success" => true,
            "message" => "Appointment was deleted."
        ));
    } else {
        http_response_code(503);
        echo json_encode(array(
            "success" => false,
            "message" => "Unable to delete appointment."
        ));
    }
} else {
    http_response_code(400);
    echo json_encode(array(
        "success" => false,
        "message" => "Unable to delete appointment. APPID is required."
    ));
}
?>