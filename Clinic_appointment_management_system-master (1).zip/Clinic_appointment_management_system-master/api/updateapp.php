<?php
// Add this to suppress deprecation warnings during development
error_reporting(E_ALL & ~E_DEPRECATED);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../model/Appointment.php';

$database = new Database();
$db = $database->getConnection();

$appointment = new Appointment($db);

$data = json_decode(file_get_contents("php://input"));

if(
    !empty($data->APPID) &&
    !empty($data->email) &&
    !empty($data->phone) &&
    !empty($data->place) &&
    !empty($data->date) &&
    !empty($data->time)
) {
    // First, check if appointment exists
    $existingAppointment = $appointment->getById($data->APPID);
    
    if(!$existingAppointment) {
        http_response_code(404);
        echo json_encode(array(
            "success" => false,
            "message" => "Appointment not found."
        ));
        exit;
    }
    
    // Set appointment properties with CORRECT property names
    $appointment->APPID = $data->APPID;
    $appointment->Pemail = $data->email;      // Use Pemail, not Email
    $appointment->Pphone = $data->phone;      // Use Pphone, not Phone
    $appointment->APPplace = $data->place;    // Use APPplace, not APPPlace
    $appointment->APPdate = $data->date;      // Use APPdate, not APPDate
    $appointment->APPtime = $data->time;      // Use APPtime, not APPTime
    $appointment->APPreason = !empty($data->reason) ? $data->reason : $existingAppointment['APPreason'];
    
    // Use existing status if not provided, otherwise use provided status
    $appointment->status = !empty($data->status) ? $data->status : $existingAppointment['status'];
    
    // Update appointment
    if($appointment->update()) {
        http_response_code(200);
        echo json_encode(array(
            "success" => true,
            "message" => "Appointment was updated."
        ));
    } else {
        http_response_code(503);
        echo json_encode(array(
            "success" => false,
            "message" => "Unable to update appointment."
        ));
    }
} else {
    http_response_code(400);
    echo json_encode(array(
        "success" => false,
        "message" => "Unable to update appointment. Required data is incomplete.",
        "required_fields" => "APPID, email, phone, place, date, time"
    ));
}
?>