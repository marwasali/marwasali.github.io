-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 07, 2026 at 05:21 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webdevproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_app`
--

CREATE TABLE `book_app` (
  `APPID` int(10) NOT NULL,
  `Pemail` varchar(255) NOT NULL,
  `Pphone` varchar(15) NOT NULL,
  `APPplace` varchar(50) NOT NULL,
  `APPdate` date NOT NULL,
  `APPtime` time NOT NULL,
  `APPreason` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'scheduled'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DEPID` int(11) NOT NULL,
  `DEPname` char(100) NOT NULL,
  `DEPhead` char(100) NOT NULL,
  `DEPemail` varchar(255) NOT NULL,
  `DEPphone` varchar(15) NOT NULL,
  `DEPstaffcount` int(100) NOT NULL,
  `DEPlocation` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `DOCTORID` int(11) NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Age` int(11) DEFAULT NULL,
  `Gender` enum('male','female') DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Mobile` varchar(20) NOT NULL,
  `MaritalStatus` varchar(20) DEFAULT NULL,
  `Experience` int(11) DEFAULT NULL,
  `Bio` text DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Rating` float DEFAULT NULL,
  `Status` enum('on','off') DEFAULT 'on',
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdatedAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `BloodGroup` enum('A+','A-','B+','B-','AB+','AB-','O+','O-') DEFAULT NULL,
  `Photo` varchar(255) DEFAULT NULL,
  `Qualification` varchar(255) DEFAULT NULL,
  `Designation` varchar(100) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `Wilaya` varchar(100) DEFAULT NULL,
  `Daira` varchar(100) DEFAULT NULL,
  `PostalCode` varchar(20) DEFAULT NULL,
  `Username` varchar(100) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`DOCTORID`, `FirstName`, `LastName`, `Age`, `Gender`, `Email`, `Mobile`, `MaritalStatus`, `Experience`, `Bio`, `Phone`, `Rating`, `Status`, `CreatedAt`, `UpdatedAt`, `BloodGroup`, `Photo`, `Qualification`, `Designation`, `Address`, `Wilaya`, `Daira`, `PostalCode`, `Username`, `Password`) VALUES
(1, 'Ahmed', 'Benali', 45, 'male', 'ahmed.benali@hopecare.dz', '0551234567', 'married', 20, 'Experienced cardiologist specializing in heart disease prevention and treatment.', '023456789', 4.8, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'A+', NULL, 'MBBS, MD', 'Senior Doctor', '15 Rue Didouche Mourad', 'Algiers', 'Sidi M\'Hamed', '16000', 'dr.benali', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(2, 'Fatima', 'Meziane', 38, 'female', 'fatima.meziane@hopecare.dz', '0661234567', 'married', 12, 'Pediatric specialist with focus on child development and preventive care.', '041234567', 4.9, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'O+', NULL, 'MBBS, MD', 'Consultant', '45 Boulevard Zirout Youcef', 'Oran', 'Oran', '31000', 'dr.meziane', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(3, 'Karim', 'Mammeri', 42, 'male', 'karim.mammeri@hopecare.dz', '0771234567', 'single', 15, 'Neurology expert specializing in brain and nervous system disorders.', '031234567', 4.7, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'B+', NULL, 'MBBS, DM', 'Specialist', '23 Rue Larbi Ben M\'hidi', 'Constantine', 'Constantine', '25000', 'dr.mammeri', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(4, 'Samira', 'Boukhari', 35, 'female', 'samira.boukhari@hopecare.dz', '0551234568', 'married', 10, 'Gynecology and obstetrics specialist. Committed to women\'s health.', '038234567', 4.9, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'AB+', NULL, 'MBBS, MS', 'Consultant', '67 Avenue de l\'ALN', 'Annaba', 'Annaba', '23000', 'dr.boukhari', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(5, 'Youcef', 'Cherif', 50, 'male', 'youcef.cherif@hopecare.dz', '0661234568', 'married', 25, 'Orthopedic surgeon with expertise in joint replacement.', '033234567', 4.6, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'O-', NULL, 'MBBS, MS', 'Senior Doctor', '12 Rue des Frères Bouadou', 'Batna', 'Batna', '05000', 'dr.cherif', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(6, 'Amina', 'Lahouel', 40, 'female', 'amina.lahouel@hopecare.dz', '0771234568', 'divorced', 14, 'Dermatologist specializing in skin conditions and cosmetic dermatology.', '036234567', 4.8, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'A-', NULL, 'MBBS, MD', 'Specialist', '89 Boulevard du 1er Novembre', 'Sétif', 'Sétif', '19000', 'dr.lahouel', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(7, 'Rachid', 'Hamdi', 47, 'male', 'rachid.hamdi@hopecare.dz', '0551234569', 'married', 18, 'General surgeon with extensive experience in laparoscopic surgeries.', '025234567', 4.7, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'B-', NULL, 'MBBS, MS', 'Senior Doctor', '34 Rue Hassiba Ben Bouali', 'Blida', 'Blida', '09000', 'dr.hamdi', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(8, 'Leila', 'Boudjema', 33, 'female', 'leila.boudjema@hopecare.dz', '0661234569', 'single', 7, 'Psychiatrist focusing on anxiety, depression, and cognitive behavioral therapy.', '034234567', 4.9, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'A+', NULL, 'MBBS, MD', 'Specialist', '56 Avenue Amirouche', 'Béjaïa', 'Béjaïa', '06000', 'dr.boudjema', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(9, 'Mohamed', 'Kaci', 44, 'male', 'mohamed.kaci@hopecare.dz', '0771234569', 'married', 16, 'Radiologist specialized in MRI, CT scans, and interventional radiology.', '026234567', 4.6, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'O+', NULL, 'MBBS, MD', 'Consultant', '78 Rue Colonel Amirouche', 'Tizi Ouzou', 'Tizi Ouzou', '15000', 'dr.kaci', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(10, 'Nadia', 'Saidi', 36, 'female', 'nadia.saidi@hopecare.dz', '0551234570', 'married', 9, 'Internal medicine physician with focus on diabetes management.', '029234567', 4.8, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'AB-', NULL, 'MBBS, MD', 'Specialist', '90 Boulevard Mohamed V', 'Ouargla', 'Ouargla', '30000', 'dr.saidi', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(11, 'Samir', 'Boudria', 41, 'male', 'samir.boudria@hopecare.dz', '0661234570', 'married', 13, 'ENT specialist treating ear, nose, and throat disorders.', '023345678', 4.7, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'B+', NULL, 'MBBS, MS', 'Consultant', '45 Rue de la Liberté', 'Algiers', 'Bab El Oued', '16030', 'dr.boudria', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(12, 'Malika', 'Zenati', 39, 'female', 'malika.zenati@hopecare.dz', '0771234570', 'single', 11, 'Ophthalmologist specializing in cataract surgery.', '041345678', 4.9, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'A+', NULL, 'MBBS, MS', 'Specialist', '23 Avenue de la République', 'Oran', 'Es Senia', '31100', 'dr.zenati', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(13, 'Hicham', 'Bensalah', 48, 'male', 'hicham.bensalah@hopecare.dz', '0551234571', 'married', 19, 'Urologist with expertise in kidney stones and prostate issues.', '031345678', 4.6, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'O-', NULL, 'MBBS, MS', 'Senior Doctor', '67 Rue Belouizdad', 'Constantine', 'El Khroub', '25100', 'dr.bensalah', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(14, 'Zineb', 'Taibi', 34, 'female', 'zineb.taibi@hopecare.dz', '0661234571', 'married', 8, 'Oncologist dedicated to cancer treatment and patient care.', '038345678', 4.8, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'A-', NULL, 'MBBS, DM', 'Specialist', '12 Boulevard de la Révolution', 'Annaba', 'El Bouni', '23200', 'dr.taibi', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(15, 'Bilal', 'Mansouri', 43, 'male', 'bilal.mansouri@hopecare.dz', '0771234571', 'married', 15, 'Anesthesiologist ensuring patient safety during surgeries.', '033345678', 4.7, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'B+', NULL, 'MBBS, MD', 'Consultant', '89 Avenue de l\'Indépendance', 'Batna', 'Arris', '05300', 'dr.mansouri', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(16, 'Sarah', 'Belkacem', 37, 'female', 'sarah.belkacem@hopecare.dz', '0551234572', 'single', 10, 'Cardiologist focused on preventive cardiology.', '036345678', 4.9, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'AB+', NULL, 'MBBS, MD', 'Specialist', '34 Rue Emir Abdelkader', 'Sétif', 'El Eulma', '19200', 'dr.belkacem', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(17, 'Redouane', 'Brahimi', 46, 'male', 'redouane.brahimi@hopecare.dz', '0661234572', 'married', 17, 'Pediatrician specializing in neonatal care.', '025345678', 4.6, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'O+', NULL, 'MBBS, MD', 'Senior Doctor', '56 Boulevard Che Guevara', 'Blida', 'Boufarik', '09100', 'dr.brahimi', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(18, 'Dalila', 'Mahdi', 32, 'female', 'dalila.mahdi@hopecare.dz', '0771234572', 'single', 6, 'Dermatologist with special interest in acne treatment.', '034345678', 4.8, 'on', '2026-01-30 22:23:56', '2026-01-30 22:41:21', 'A+', 'uploads/doctors/doctor_18_1769812881.jpg', 'MBBS, MD', 'Junior Doctor', '78 Rue de la Paix', '06 - Béjaïa', 'Akbou', '06200', 'dr.mahdi', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(19, 'Amine', 'Taleb', 49, 'male', 'amine.taleb@hopecare.dz', '0551234573', 'married', 21, 'Neurologist with advanced training in epilepsy.', '026345678', 4.7, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'B-', NULL, 'MBBS, DM', 'Senior Doctor', '90 Avenue Ahmed Zabana', 'Tizi Ouzou', 'Azazga', '15350', 'dr.taleb', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(20, 'Houria', 'Djelloul', 35, 'female', 'houria.djelloul@hopecare.dz', '0661234573', 'married', 9, 'General surgeon specializing in abdominal surgery.', '029345678', 4.8, 'on', '2026-01-30 22:23:56', '2026-01-30 22:23:56', 'O-', NULL, 'MBBS, MS', 'Specialist', '45 Rue 1er Novembre', 'Ouargla', 'Touggourt', '30200', 'dr.djelloul', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
(12345667, 'lidya', 'jdjsk', 36, 'female', 'lydiaa.sali@ensia.edu.dz', '84589547756', NULL, NULL, 'ijfsdukfhkjd', '43576547', NULL, 'off', '2026-01-31 06:27:07', '2026-01-31 06:27:07', 'O-', 'uploads/doctors/doctor_12345667_1769840827.gif', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_schedule`
--

CREATE TABLE `doctor_schedule` (
  `ScheduleID` int(11) NOT NULL,
  `DoctorID` int(11) NOT NULL,
  `DayOfWeek` enum('monday','tuesday','wednesday','thursday','friday','saturday','sunday') NOT NULL,
  `StartTime` time NOT NULL,
  `EndTime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_schedule`
--

INSERT INTO `doctor_schedule` (`ScheduleID`, `DoctorID`, `DayOfWeek`, `StartTime`, `EndTime`) VALUES
(11, 1, 'monday', '08:00:00', '16:00:00'),
(12, 1, 'tuesday', '08:00:00', '16:00:00'),
(13, 1, 'wednesday', '08:00:00', '16:00:00'),
(14, 1, 'thursday', '08:00:00', '16:00:00'),
(15, 1, 'saturday', '09:00:00', '13:00:00'),
(16, 2, 'sunday', '09:00:00', '17:00:00'),
(17, 2, 'monday', '09:00:00', '17:00:00'),
(18, 2, 'tuesday', '09:00:00', '17:00:00'),
(19, 2, 'wednesday', '09:00:00', '17:00:00'),
(20, 2, 'thursday', '09:00:00', '17:00:00'),
(21, 3, 'monday', '10:00:00', '18:00:00'),
(22, 3, 'wednesday', '10:00:00', '18:00:00'),
(23, 3, 'thursday', '10:00:00', '18:00:00'),
(24, 3, 'saturday', '10:00:00', '14:00:00'),
(25, 4, 'sunday', '08:00:00', '15:00:00'),
(26, 4, 'monday', '08:00:00', '15:00:00'),
(27, 4, 'tuesday', '08:00:00', '15:00:00'),
(28, 4, 'wednesday', '08:00:00', '15:00:00'),
(29, 4, 'thursday', '08:00:00', '15:00:00'),
(30, 5, 'monday', '08:00:00', '16:00:00'),
(31, 5, 'tuesday', '08:00:00', '16:00:00'),
(32, 5, 'thursday', '08:00:00', '16:00:00'),
(33, 5, 'friday', '08:00:00', '12:00:00'),
(34, 6, 'sunday', '09:00:00', '17:00:00'),
(35, 6, 'tuesday', '09:00:00', '17:00:00'),
(36, 6, 'wednesday', '09:00:00', '17:00:00'),
(37, 6, 'thursday', '09:00:00', '17:00:00'),
(38, 6, 'saturday', '09:00:00', '13:00:00'),
(39, 7, 'monday', '07:00:00', '15:00:00'),
(40, 7, 'tuesday', '07:00:00', '15:00:00'),
(41, 7, 'wednesday', '07:00:00', '15:00:00'),
(42, 7, 'thursday', '07:00:00', '15:00:00'),
(43, 7, 'friday', '07:00:00', '12:00:00'),
(44, 8, 'sunday', '10:00:00', '18:00:00'),
(45, 8, 'monday', '10:00:00', '18:00:00'),
(46, 8, 'tuesday', '10:00:00', '18:00:00'),
(47, 8, 'thursday', '10:00:00', '18:00:00'),
(48, 9, 'monday', '08:00:00', '16:00:00'),
(49, 9, 'tuesday', '08:00:00', '16:00:00'),
(50, 9, 'wednesday', '08:00:00', '16:00:00'),
(51, 9, 'thursday', '08:00:00', '16:00:00'),
(52, 9, 'saturday', '08:00:00', '12:00:00'),
(53, 10, 'sunday', '09:00:00', '17:00:00'),
(54, 10, 'monday', '09:00:00', '17:00:00'),
(55, 10, 'wednesday', '09:00:00', '17:00:00'),
(56, 10, 'thursday', '09:00:00', '17:00:00'),
(57, 10, 'friday', '09:00:00', '13:00:00'),
(58, 11, 'monday', '08:30:00', '16:30:00'),
(59, 11, 'tuesday', '08:30:00', '16:30:00'),
(60, 11, 'wednesday', '08:30:00', '16:30:00'),
(61, 11, 'thursday', '08:30:00', '16:30:00'),
(62, 12, 'sunday', '09:00:00', '17:00:00'),
(63, 12, 'monday', '09:00:00', '17:00:00'),
(64, 12, 'tuesday', '09:00:00', '17:00:00'),
(65, 12, 'thursday', '09:00:00', '17:00:00'),
(66, 12, 'saturday', '09:00:00', '13:00:00'),
(67, 13, 'monday', '08:00:00', '16:00:00'),
(68, 13, 'wednesday', '08:00:00', '16:00:00'),
(69, 13, 'thursday', '08:00:00', '16:00:00'),
(70, 13, 'friday', '08:00:00', '12:00:00'),
(71, 14, 'sunday', '08:00:00', '16:00:00'),
(72, 14, 'monday', '08:00:00', '16:00:00'),
(73, 14, 'tuesday', '08:00:00', '16:00:00'),
(74, 14, 'wednesday', '08:00:00', '16:00:00'),
(75, 14, 'thursday', '08:00:00', '16:00:00'),
(76, 15, 'monday', '07:00:00', '19:00:00'),
(77, 15, 'tuesday', '07:00:00', '19:00:00'),
(78, 15, 'wednesday', '07:00:00', '19:00:00'),
(79, 15, 'thursday', '07:00:00', '19:00:00'),
(80, 15, 'friday', '07:00:00', '15:00:00'),
(81, 16, 'sunday', '08:00:00', '16:00:00'),
(82, 16, 'tuesday', '08:00:00', '16:00:00'),
(83, 16, 'wednesday', '08:00:00', '16:00:00'),
(84, 16, 'thursday', '08:00:00', '16:00:00'),
(85, 16, 'saturday', '09:00:00', '13:00:00'),
(86, 17, 'sunday', '09:00:00', '17:00:00'),
(87, 17, 'monday', '09:00:00', '17:00:00'),
(88, 17, 'tuesday', '09:00:00', '17:00:00'),
(89, 17, 'wednesday', '09:00:00', '17:00:00'),
(94, 19, 'sunday', '08:00:00', '16:00:00'),
(95, 19, 'monday', '08:00:00', '16:00:00'),
(96, 19, 'wednesday', '08:00:00', '16:00:00'),
(97, 19, 'thursday', '08:00:00', '16:00:00'),
(98, 19, 'friday', '08:00:00', '12:00:00'),
(99, 20, 'monday', '07:00:00', '15:00:00'),
(100, 20, 'tuesday', '07:00:00', '15:00:00'),
(101, 20, 'wednesday', '07:00:00', '15:00:00'),
(102, 20, 'thursday', '07:00:00', '15:00:00'),
(103, 20, 'saturday', '08:00:00', '12:00:00'),
(104, 18, 'monday', '10:00:00', '18:00:00'),
(105, 18, 'tuesday', '10:00:00', '18:00:00'),
(106, 18, 'thursday', '10:00:00', '18:00:00'),
(107, 18, 'saturday', '10:00:00', '14:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `doc_specialty`
--

CREATE TABLE `doc_specialty` (
  `DoctorID` int(11) NOT NULL,
  `SpecialtyID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doc_specialty`
--

INSERT INTO `doc_specialty` (`DoctorID`, `SpecialtyID`) VALUES
(1, 1),
(2, 4),
(3, 3),
(4, 6),
(5, 5),
(6, 2),
(7, 9),
(8, 7),
(9, 8),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 1),
(17, 4),
(18, 2),
(19, 3),
(20, 9),
(12345667, 2),
(12345667, 15);

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `PID` int(11) NOT NULL,
  `Pfirstname` varchar(100) NOT NULL,
  `Plastname` varchar(100) NOT NULL,
  `Pemail` varchar(100) DEFAULT NULL,
  `Pphone` varchar(20) DEFAULT NULL,
  `Paddress` text DEFAULT NULL,
  `Pdate_of_birth` date DEFAULT NULL,
  `Pgender` enum('male','female') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `records`
--

CREATE TABLE `records` (
  `RECORDSID` int(10) NOT NULL,
  `record_date` date NOT NULL,
  `diagnosis` text NOT NULL,
  `treatment` text NOT NULL,
  `patient_name` varchar(100) NOT NULL,
  `doctor_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `records`
--

INSERT INTO `records` (`RECORDSID`, `record_date`, `diagnosis`, `treatment`, `patient_name`, `doctor_name`) VALUES
(1, '2026-02-03', 'Test Diagnosis', 'Test Treatment', 'Test Patient', 'Test Doctor'),
(3, '2026-02-04', 'vkjc bgivsfu', 'fsvkjbsvifub', 'fkjdvdbdgziub', 'ssvkhcvsjhu'),
(4, '2026-12-12', 'idk', 'idk', 'malak immessaoudene', 'ikram');

-- --------------------------------------------------------

--
-- Table structure for table `specialties`
--

CREATE TABLE `specialties` (
  `SpecialtyID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `specialties`
--

INSERT INTO `specialties` (`SpecialtyID`, `Name`) VALUES
(15, 'Anesthesiology'),
(1, 'Cardiology'),
(2, 'Dermatology'),
(11, 'ENT'),
(9, 'General Surgery'),
(6, 'Gynecology'),
(10, 'Internal Medicine'),
(3, 'Neurology'),
(14, 'Oncology'),
(12, 'Ophthalmology'),
(5, 'Orthopedics'),
(4, 'Pediatrics'),
(7, 'Psychiatry'),
(8, 'Radiology'),
(13, 'Urology');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_app`
--
ALTER TABLE `book_app`
  ADD PRIMARY KEY (`APPID`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`DEPID`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`DOCTORID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `doctor_schedule`
--
ALTER TABLE `doctor_schedule`
  ADD PRIMARY KEY (`ScheduleID`),
  ADD UNIQUE KEY `DoctorID` (`DoctorID`,`DayOfWeek`);

--
-- Indexes for table `doc_specialty`
--
ALTER TABLE `doc_specialty`
  ADD PRIMARY KEY (`DoctorID`,`SpecialtyID`),
  ADD KEY `SpecialtyID` (`SpecialtyID`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`PID`);

--
-- Indexes for table `records`
--
ALTER TABLE `records`
  ADD PRIMARY KEY (`RECORDSID`);

--
-- Indexes for table `specialties`
--
ALTER TABLE `specialties`
  ADD PRIMARY KEY (`SpecialtyID`),
  ADD UNIQUE KEY `Name` (`Name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_app`
--
ALTER TABLE `book_app`
  MODIFY `APPID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `DEPID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `DOCTORID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483648;

--
-- AUTO_INCREMENT for table `doctor_schedule`
--
ALTER TABLE `doctor_schedule`
  MODIFY `ScheduleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `PID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `records`
--
ALTER TABLE `records`
  MODIFY `RECORDSID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `specialties`
--
ALTER TABLE `specialties`
  MODIFY `SpecialtyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `doctor_schedule`
--
ALTER TABLE `doctor_schedule`
  ADD CONSTRAINT `doctor_schedule_ibfk_1` FOREIGN KEY (`DoctorID`) REFERENCES `doctors` (`DOCTORID`) ON DELETE CASCADE;

--
-- Constraints for table `doc_specialty`
--
ALTER TABLE `doc_specialty`
  ADD CONSTRAINT `doc_specialty_ibfk_1` FOREIGN KEY (`DoctorID`) REFERENCES `doctors` (`DOCTORID`) ON DELETE CASCADE,
  ADD CONSTRAINT `doc_specialty_ibfk_2` FOREIGN KEY (`SpecialtyID`) REFERENCES `specialties` (`SpecialtyID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
