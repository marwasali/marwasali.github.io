<?php

$host = "YOUR_DB_HOST";    
$user = "YOUR_DB_USER";      
$pass = "YOUR_DB_PASS";     
$db_name = "YOUR_DB_NAME";  

// Create a connection
$conn = new mysqli($host, $user, $pass, $db_name);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed. Please try again later."); // generic error message
}

// Set charset
$conn->set_charset("utf8mb4");
?>
