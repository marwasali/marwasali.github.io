<?php
require_once "../config/db.php";
// Enable error display
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Try to include db.php and catch any errors
try {
    require_once "../config/db.php";
    echo "<!-- Database connected successfully -->";
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

//displqy message 
session_start();
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $messageType = $_SESSION['message_type'];
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
    echo "<script>showNotification('$message', '$messageType');</script>";
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctors Grid - Apollo</title>
    <link rel="stylesheet" href="../css/doctors.css">
</head>
<body>
    <nav>
      <div class="nav-left">
            <div class="logo">
                <div class="logo-icon">+</div>
                <span>HopeCare</span>
            </div>
            <ul class="nav-links">
                <li><a href="../html/home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle">Management</a>
                    <div class="dropdown-menu">
                        <a href="../html/doctors.php">Doctors</a>
                        <a href="../html/patient.php">Patients</a>
                        <a href="../html/departments.php">Departments</a>
                        <a href="../html/records.php">Medical Records</a>
                    </div>
                </li>
                <li><a href="../html/app.php">Appointments</a></li>
                <li><a href="../html/feedback.php">Feedback</a></li>
            </ul>
        </div>
     
    </nav>

    <div class="container">
        <main class="main-content">
     

            <div class="breadcrumb">
                <span class="icon">🏠</span>
                <span>/</span>
                <span>Doctors</span>
            </div>

            <div class="content-header">
                <h2>Doctors</h2>
                <button class="btn-primary" onclick="window.location.href= 'add-doctor.php' ">
                    <span>+</span> Add Doctor
                </button>
            </div>

            <!-- Doctors Table -->
            <table class="doctors-table">
                <thead>
                    <tr>
                        <th>Doctor ID</th>
                        <th>Name</th>
                        <th>Specialty</th>
                        <th>Experience</th>
                        <th>Contact</th>
                        <th>Rating</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="doctorsTableBody">
                    <!-- Doctors will be loaded here by JavaScript -->
                </tbody>
            </table>
        </main>
    </div>

    <script src="../javascript/doctors.js"></script>
</body>
</html>