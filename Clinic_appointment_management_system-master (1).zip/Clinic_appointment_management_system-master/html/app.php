<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments List</title>
    <link rel="stylesheet" href="..\css\app.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body>
    <header>
        <nav>
            <div class="nav-left">
                <div class="logo">
                    <div class="logo-icon">+</div>
                    <span>HopeCare</span>
                </div>
                <ul class="nav-links">
                    <li><a href="index.html">Home</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle">Management</a>
                        <div class="dropdown-menu">
                            <a href="doctors.html">Doctors</a>
                            <a href="patient.html">Patients</a>
                            <a href="departments.html">Departments</a>
                            <a href="records.html">Medical Records</a>
                        </div>
                    </li>
                    <li><a href="app.php">Appointments</a></li>
                    <li><a href="feedback.html">Feedback</a></li>
                </ul>
            </div>
            <div class="nav-right">
                <button class="logout-btn" onclick="logout()">Logout</button>
            </div>
        </nav>
    </header>

    <main>
        <div class="app">
            <h1>Appointments List</h1>
            
            <!-- Add Appointment Button -->
            <div style="text-align: right; width: 100%; margin-bottom: 20px;">
                <button class="add-btn" onclick="window.location.href='bookapp.html'">
                    <i class="fas fa-plus"></i> Add New Appointment
                </button>
            </div>

            <table class="app-table">
                <thead>
                    <tr>
                        <th>Patient Email</th>
                        <th>Phone</th>
                        <th>Place</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // SIMPLE DATABASE CONNECTION - USE THE SONE FROM YOUR DEBUG.PHP
                    $host = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "webdevproject";
                    
                    // Create connection
                    $conn = new mysqli($host, $username, $password, $dbname);
                    
                    // Check connection
                    if ($conn->connect_error) {
                        echo "<tr><td colspan='8' style='color: red; text-align: center;'>Connection failed: " . $conn->connect_error . "</td></tr>";
                    } else {
                        // Query to get all appointments
                        $sql = "SELECT * FROM book_app ORDER BY APPdate DESC, APPtime DESC";
                        $result = $conn->query($sql);
                        
                        if ($result && $result->num_rows > 0) {
                            // Loop through each appointment
                            while($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row['Pemail']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['Pphone']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['APPplace']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['APPdate']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['APPtime']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['APPreason']) . "</td>";
                                
                                // Status with color
                                $status = $row['status'] ?: 'Scheduled';
                                $status_class = "status-scheduled";
                                
                                if (strtolower($status) == 'confirmed') {
                                    $status_class = "status-confirmed";
                                } elseif (strtolower($status) == 'cancelled') {
                                    $status_class = "status-cancelled";
                                } elseif (strtolower($status) == 'completed') {
                                    $status_class = "status-completed";
                                }
                                
                                echo "<td><span class='" . $status_class . "'>" . htmlspecialchars($status) . "</span></td>";
                                echo "<td>";
                                echo "<i class='fas fa-edit edit-icon' onclick=\"editAppointment(" . $row['APPID'] . ")\" title='Edit'></i>";
                                echo "<i class='fas fa-trash delete-icon' onclick=\"deleteAppointment(" . $row['APPID'] . ")\" title='Delete'></i>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8' style='text-align: center; padding: 40px; color: #666;'>No appointments found.</td></tr>";
                        }
                        
                        $conn->close();
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>

    <script>
    function editAppointment(id) {
        alert('Edit appointment ID: ' + id);
        // You can implement edit functionality later
    }
    
    function deleteAppointment(id) {
        if (confirm('Are you sure you want to delete appointment ID: ' + id + '?')) {
            window.location.href = '../api/delete_appointment.php?id=' + id;
        }
    }
    
    function logout() {
        if (confirm('Are you sure you want to logout?')) {
            window.location.href = 'login.html';
        }
    }
    </script>
</body>
</html>