<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once "../config/db.php";

// Get doctor ID from URL parameter
$doctor_id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';

// Debug: Show what ID we received
error_log("Received doctor ID: " . $doctor_id);

if (empty($doctor_id)) {
    echo "No doctor ID provided. <a href='doctors.php'>Go back to doctors list</a>";
    exit();
}

// Fetch doctor profile from database using DOCTORID as string
$query = "SELECT * FROM doctors WHERE DOCTORID = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("s", $doctor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    error_log("Doctor not found in database. ID searched: " . $doctor_id);
    echo "<h2>Doctor not found with ID: " . htmlspecialchars($doctor_id) . "</h2>";
    echo "<p>Debug info:</p>";
    echo "<ul>";
    echo "<li>Received ID: " . htmlspecialchars($doctor_id) . "</li>";
    echo "<li>ID Type: " . gettype($doctor_id) . "</li>";
    
    // Show what IDs exist in the database
    $debug_query = "SELECT DOCTORID FROM doctors LIMIT 10";
    $debug_result = mysqli_query($conn, $debug_query);
    echo "<li>Sample Doctor IDs in database: ";
    $ids = [];
    while ($row = mysqli_fetch_assoc($debug_result)) {
        $ids[] = $row['DOCTORID'];
    }
    echo implode(', ', $ids) . "</li>";
    echo "</ul>";
    echo "<a href='doctors.php' style='padding: 10px 20px; background: #38b2ac; color: white; text-decoration: none; border-radius: 4px; display: inline-block; margin-top: 20px;'>Go back to doctors list</a>";
    exit();
}

$doctor = $result->fetch_assoc();
$stmt->close();

// Combine first and last name
$doctorFullName = trim($doctor['FirstName'] . ' ' . $doctor['LastName']);

// Fetch doctor's specialties by joining doc_specialty and specialties tables
$specialties = [];
$specialties_query = "SELECT s.Name 
                      FROM doc_specialty ds 
                      INNER JOIN specialties s ON ds.SpecialtyID = s.SpecialtyID 
                      WHERE ds.DoctorID = ?";
if ($spec_stmt = $conn->prepare($specialties_query)) {
    $spec_stmt->bind_param("s", $doctor_id);
    $spec_stmt->execute();
    $spec_result = $spec_stmt->get_result();
    while ($row = $spec_result->fetch_assoc()) {
        $specialties[] = $row['Name'];
    }
    $spec_stmt->close();
}

// If no specialties found, add a default one
if (empty($specialties)) {
    $specialties = ['General Practice'];
}

// Fetch availability schedule
$availability = [];
$schedule_query = "SELECT DayOfWeek, StartTime, EndTime FROM doctor_schedule WHERE DoctorID = ?";
if ($sched_stmt = $conn->prepare($schedule_query)) {
    $sched_stmt->bind_param("s", $doctor_id);
    $sched_stmt->execute();
    $sched_result = $sched_stmt->get_result();
    while ($row = $sched_result->fetch_assoc()) {
        $start = date('g:iA', strtotime($row['StartTime']));
        $end = date('g:iA', strtotime($row['EndTime']));
        $availability[strtolower($row['DayOfWeek'])] = $start . ' - ' . $end;
    }
    $sched_stmt->close();
}

// Set default availability if none exists
$days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
foreach ($days as $day) {
    if (!isset($availability[$day])) {
        $availability[$day] = 'Holiday';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($doctorFullName); ?> - Profile</title>
    <link rel="stylesheet" href="../css/doctors.css">
    <link rel="stylesheet" href="../css/view_doctor_profile.css">
</head>
<body>

    <!-- nav bar -->
    <nav>
        <div class="nav-left">
            <div class="logo">
                <div class="logo-icon">+</div>
                <span>HopeCare</span>
            </div>
            <ul class="nav-links">
                <li><a href="../html/home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle">Management</a>
                    <div class="dropdown-menu">
                        <a href="../html/doctors.php">Doctors</a>
                        <a href="../html/patient.php">Patients</a>
                        <a href="../html/departments.php">Departments</a>
                        <a href="../html/records.php">Medical Records</a>
                    </div>
                </li>
                <li><a href="../html/app.php">Appointments</a></li>
                <li><a href="../html/feedback.php">Feedback</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="breadcrumb">
            <br><br><br>
            <span class="icon">🏠</span>
            <span>/</span>
            <span>Doctors Profile</span>
        </div>

        <div class="date-range">
            <span class="icon">📅</span>
            <span id="dateRangeDisplay"></span>
        </div>

        <!-- Profile Header -->
        <div class="profile-header">
            <div class="profile-main">
                <?php 
                // Determine photo path
                $photoPath = '../assets/images/doctor-avatar.jpg'; // default
                
                // Check if doctor has a custom photo
                if (!empty($doctor['Photo']) && file_exists('../' . $doctor['Photo'])) {
                    $photoPath = '../' . $doctor['Photo'];
                } elseif ($doctor['Gender'] == 'female') {
                    $photoPath = '../assets/images/female-avatar.jpg';
                } elseif ($doctor['Gender'] == 'male') {
                    $photoPath = '../assets/images/doctor-avatar.jpg';
                }
                ?>
                <img src="<?php echo htmlspecialchars($photoPath); ?>" 
                     alt="<?php echo htmlspecialchars($doctorFullName); ?>" 
                     class="doctor-photo" 
                     id="doctorPhoto"
                     onerror="this.src='../assets/images/doctor-avatar.jpg'">
                <div class="profile-info">
                    <span class="status-badge <?php echo strtolower($doctor['Status'] ?? 'on'); ?>" id="statusBadge">
                        <?php 
                        $status = $doctor['Status'] ?? 'on';
                        if (strtolower($status) == 'on') {
                            echo '🟢 Available';
                        } else {
                            echo '🔴 Offline';
                        }
                        ?>
                    </span>
                    <p class="greeting">Good Morning,</p>
                    <h2 id="doctorName">Dr. <?php echo htmlspecialchars($doctorFullName); ?></h2>
                    <p class="credentials" id="doctorCredentials">
                        <?php 
                        $credentials = [];
                        if (!empty($doctor['Experience'])) {
                            $credentials[] = $doctor['Experience'] . ' years experience';
                        }
                        if (!empty($specialties)) {
                            $credentials[] = implode(', ', $specialties);
                        }
                        echo htmlspecialchars(implode(' • ', $credentials));
                        ?>
                    </p>
                    <p class="info-item">
                        👤 <?php echo htmlspecialchars(ucfirst($doctor['Gender'] ?? 'N/A')); ?> • 
                        🎂 <?php echo htmlspecialchars($doctor['Age'] ?? 'N/A'); ?> years old
                    </p>
                    <?php if (!empty($doctor['Mobile'])): ?>
                    <p class="contact">📞 <?php echo htmlspecialchars($doctor['Mobile']); ?></p>
                    <?php endif; ?>
                    <?php if (!empty($doctor['Email'])): ?>
                    <p class="contact">✉️ <?php echo htmlspecialchars($doctor['Email']); ?></p>
                    <?php endif; ?>
                    <?php if (!empty($doctor['BloodGroup'])): ?>
                    <p class="info-item">🩸 Blood Group: <?php echo htmlspecialchars($doctor['BloodGroup']); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Profile Content -->
        <div class="profile-content">
            <div class="profile-main-content">
                <!-- Bio Tab -->
                <div class="tab-content active" id="bio">
                    <h3>About Dr. <?php echo htmlspecialchars($doctorFullName); ?></h3>
                    <p id="doctorBio">
                        <?php 
                        if (!empty($doctor['Bio'])) {
                            echo nl2br(htmlspecialchars($doctor['Bio']));
                        } else {
                            echo "Dr. " . htmlspecialchars($doctorFullName) . " is a dedicated healthcare professional with " . 
                                 htmlspecialchars($doctor['Experience'] ?? '0') . " years of experience. ";
                            if (!empty($doctor['MaritalStatus'])) {
                                echo "Marital Status: " . htmlspecialchars($doctor['MaritalStatus']) . ". ";
                            }
                            echo "Committed to providing quality healthcare services.";
                        }
                        ?>
                    </p>
                    
                    <h3>Specialties</h3>
                    <div class="specialities" id="specialities">
                        <?php 
                        foreach ($specialties as $specialty) {
                            echo '<span class="tag">' . htmlspecialchars($specialty) . '</span>';
                        }
                        ?>
                    </div>

                    <?php if (!empty($doctor['Qualification'])): ?>
                    <h3>Qualification</h3>
                    <p><strong><?php echo htmlspecialchars($doctor['Qualification']); ?></strong></p>
                    <?php endif; ?>

                    <?php if (!empty($doctor['Designation'])): ?>
                    <h3>Designation</h3>
                    <p><strong><?php echo htmlspecialchars($doctor['Designation']); ?></strong></p>
                    <?php endif; ?>

                    <?php if (!empty($doctor['Experience']) && $doctor['Experience'] > 0): ?>
                    <h3>Experience</h3>
                    <p><strong><?php echo htmlspecialchars($doctor['Experience']); ?></strong> years of professional medical practice</p>
                    <?php endif; ?>

                    <?php if (!empty($doctor['Rating']) && $doctor['Rating'] > 0): ?>
                    <h3>Rating</h3>
                    <p>⭐ <strong><?php echo htmlspecialchars($doctor['Rating']); ?></strong> / 5.0</p>
                    <?php endif; ?>

                    <?php if (!empty($doctor['Address']) || !empty($doctor['Wilaya'])): ?>
                    <h3>Address</h3>
                    <p>
                        <?php 
                        $addressParts = [];
                        if (!empty($doctor['Address'])) $addressParts[] = htmlspecialchars($doctor['Address']);
                        if (!empty($doctor['Daira'])) $addressParts[] = htmlspecialchars($doctor['Daira']);
                        if (!empty($doctor['Wilaya'])) $addressParts[] = htmlspecialchars($doctor['Wilaya']);
                        if (!empty($doctor['PostalCode'])) $addressParts[] = htmlspecialchars($doctor['PostalCode']);
                        echo implode(', ', $addressParts);
                        ?>
                    </p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Availability Sidebar -->
            <div class="availability-sidebar">
                <h3>Availability Schedule</h3>
                <div class="availability-schedule" id="availabilitySchedule">
                    <?php
                    $dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                    foreach ($dayNames as $dayName) {
                        $dayLower = strtolower($dayName);
                        $time = isset($availability[$dayLower]) ? $availability[$dayLower] : 'Holiday';
                        $isHoliday = ($time === 'Holiday' || $time === 'NA' || empty($time));
                        echo '<div class="schedule-day">';
                        echo '<span class="day-name">' . $dayName . '</span>';
                        echo '<span class="' . ($isHoliday ? 'day-holiday' : 'day-time') . '">' . htmlspecialchars($time) . '</span>';
                        echo '</div>';
                    }
                    ?>
                </div>
                <button class="btn-primary" style="width: 100%; margin-top: 20px;" onclick="bookAppointment()">Book Appointment</button>
            </div>
        </div>
    </div>

    <!-- Pass PHP data to JavaScript -->
    <script>
        // Doctor data from PHP
        const doctorData = <?php echo json_encode([
            'id' => $doctor['DOCTORID'],
            'firstName' => $doctor['FirstName'],
            'lastName' => $doctor['LastName'],
            'name' => $doctorFullName,
            'age' => $doctor['Age'] ?? 0,
            'gender' => $doctor['Gender'] ?? '',
            'email' => $doctor['Email'] ?? '',
            'mobile' => $doctor['Mobile'] ?? '',
            'phone' => $doctor['Phone'] ?? '',
            'maritalStatus' => $doctor['MaritalStatus'] ?? '',
            'experience' => $doctor['Experience'] ?? 0,
            'bio' => $doctor['Bio'] ?? '',
            'rating' => $doctor['Rating'] ?? 0,
            'status' => $doctor['Status'] ?? 'on',
            'bloodGroup' => $doctor['BloodGroup'] ?? '',
            'specialties' => $specialties,
            'availability' => $availability
        ]); ?>;
        
        // Debug: Log the data
        console.log('Doctor Data:', doctorData);
        
        // Set current date
        const dateElement = document.getElementById('dateRangeDisplay');
        if (dateElement) {
            dateElement.textContent = new Date().toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
        
        // Book appointment function
        function bookAppointment() {
            alert('Redirecting to appointment booking for Dr. ' + doctorData.name);
            // You can redirect to appointment page here
            // window.location.href = '../html/book-appointment.php?doctor_id=' + doctorData.id;
        }
    </script>
    
    <script src="../javascript/doctors.js"></script>
    <script src="../javascript/doctor-profile.js"></script>
</body>
</html>