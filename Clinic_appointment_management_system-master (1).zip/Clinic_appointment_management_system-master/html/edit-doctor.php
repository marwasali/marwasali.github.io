<?php
require_once "../config/db.php";

// Check if a doctor ID is provided in the URL
if (!isset($_GET['id'])) {
    header("Location: ../html/doctors.php");
    exit();
}

$doctorId = mysqli_real_escape_string($conn, $_GET['id']);

// Fetch doctor details
$sql_doctor = "SELECT * FROM doctors WHERE DOCTORID = '$doctorId'";
$result_doctor = mysqli_query($conn, $sql_doctor);

if (mysqli_num_rows($result_doctor) == 0) {
    header("Location: ../html/doctors.php");
    exit();
}

$doctor = mysqli_fetch_assoc($result_doctor);

// Fetch doctor's schedule
$sql_schedule = "SELECT * FROM doctor_schedule WHERE DoctorID = '$doctorId'";
$result_schedule = mysqli_query($conn, $sql_schedule);
$schedule = [];
while ($row = mysqli_fetch_assoc($result_schedule)) {
    $schedule[strtolower($row['DayOfWeek'])] = $row;
}

// Fetch all specialties for the dropdown
$sql_all_specialties = "SELECT * FROM specialties ORDER BY Name";
$result_all_specialties = mysqli_query($conn, $sql_all_specialties);
$allSpecialties = [];
while ($row = mysqli_fetch_assoc($result_all_specialties)) {
    $allSpecialties[] = $row;
}

// Fetch doctor's specialties
$sql_doctor_specialties = "SELECT SpecialtyID FROM doc_specialty WHERE DoctorID = '$doctorId'";
$result_doctor_specialties = mysqli_query($conn, $sql_doctor_specialties);
$doctorSpecialties = [];
while ($row = mysqli_fetch_assoc($result_doctor_specialties)) {
    $doctorSpecialties[] = $row['SpecialtyID'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Doctor - <?php echo htmlspecialchars($doctor['FirstName'] . ' ' . $doctor['LastName']); ?></title>
    <link rel="stylesheet" href="../css/doctors.css">
    <style>
        .specialty-checkboxes {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 10px;
        }
        .specialty-checkboxes label {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .upload-box {
            border: 2px dashed #ccc;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            border-radius: 8px;
        }
        .upload-box:hover {
            border-color: #38b2ac;
        }
        #imagePreview img {
            max-width: 200px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .current-photo {
            margin-bottom: 20px;
            text-align: center;
        }
        .current-photo img {
            max-width: 150px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav>
        <div class="nav-left">
            <div class="logo">
                <div class="logo-icon">+</div>
                <span>HopeCare</span>
            </div>
            <ul class="nav-links">
                <li><a href="../html/home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle">Management</a>
                    <div class="dropdown-menu">
                        <a href="../html/doctors.php">Doctors</a>
                        <a href="../html/patient.php">Patients</a>
                        <a href="../html/departments.php">Departments</a>
                        <a href="../html/records.php">Medical Records</a>
                    </div>
                </li>
                <li><a href="../html/app.php">Appointments</a></li>
                <li><a href="../html/feedback.php">Feedback</a></li>
            </ul>
        </div>
    </nav>

    <div class="breadcrumb">
        <br><br><br>
        <span class="icon">🏠</span>
        <span>/</span>
        <span>Edit Doctor</span>
    </div>
    
    <div class="date-range">
        <span class="icon">📅</span>
        <span id="currentDate"></span>
    </div>

    <div class="form-container">
        <div class="form-tabs">
            <button class="form-tab active" data-tab="personal">
                <span class="icon">📋</span>
                Personal Details
            </button>
            <button class="form-tab" data-tab="profile">
                <span class="icon">👤</span>
                Profile and Bio
            </button>
            <button class="form-tab" data-tab="availability">
                <span class="icon">📅</span>
                Availability
            </button>
            <button class="form-tab" data-tab="account">
                <span class="icon">🔐</span>
                Account Details
            </button>
        </div>

        <!-- IMPORTANT: Added enctype for file upload and changed action -->
        <form id="editDoctorForm" action="../api/edit_doctor.php" method="POST" enctype="multipart/form-data">
            <!-- Hidden field for doctor ID -->
            <input type="hidden" name="doctorId" value="<?php echo htmlspecialchars($doctorId); ?>">
            
            <!-- Personal Details Tab -->
            <div class="tab-panel active" id="personal">
                <div class="form-grid">
                    <div class="form-group">
                        <label>First Name *</label>
                        <input type="text" name="firstName" value="<?php echo htmlspecialchars($doctor['FirstName'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name *</label>
                        <input type="text" name="lastName" value="<?php echo htmlspecialchars($doctor['LastName'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Age *</label>
                        <select name="age" required>
                            <option value="">Select Age</option>
                            <?php for($i = 25; $i <= 70; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo (isset($doctor['Age']) && $doctor['Age'] == $i) ? 'selected' : ''; ?>>
                                    <?php echo $i; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Gender *</label>
                        <div class="radio-group">
                            <label>
                                <input type="radio" name="gender" value="male" <?php echo (isset($doctor['Gender']) && $doctor['Gender'] == 'male') ? 'checked' : ''; ?> required>
                                Male
                            </label>
                            <label>
                                <input type="radio" name="gender" value="female" <?php echo (isset($doctor['Gender']) && $doctor['Gender'] == 'female') ? 'checked' : ''; ?>>
                                Female
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Doctor ID * (Cannot be changed)</label>
                        <input type="text" value="<?php echo htmlspecialchars($doctor['DOCTORID'] ?? ''); ?>" readonly style="background-color: #f0f0f0;">
                    </div>
                    <div class="form-group">
                        <label>Email ID *</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($doctor['Email'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Mobile Number *</label>
                        <input type="tel" name="mobile" value="<?php echo htmlspecialchars($doctor['Mobile'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" name="phone" value="<?php echo htmlspecialchars($doctor['Phone'] ?? ''); ?>" placeholder="Enter Phone Number">
                    </div>
                    <div class="form-group">
                        <label>Marital Status</label>
                        <select name="maritalStatus">
                            <option value="">Select</option>
                            <option value="single" <?php echo (isset($doctor['MaritalStatus']) && $doctor['MaritalStatus'] == 'single') ? 'selected' : ''; ?>>Single</option>
                            <option value="married" <?php echo (isset($doctor['MaritalStatus']) && $doctor['MaritalStatus'] == 'married') ? 'selected' : ''; ?>>Married</option>
                            <option value="divorced" <?php echo (isset($doctor['MaritalStatus']) && $doctor['MaritalStatus'] == 'divorced') ? 'selected' : ''; ?>>Divorced</option>
                            <option value="widowed" <?php echo (isset($doctor['MaritalStatus']) && $doctor['MaritalStatus'] == 'widowed') ? 'selected' : ''; ?>>Widowed</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Experience (Years)</label>
                        <input type="number" name="experience" min="0" max="50" value="<?php echo htmlspecialchars($doctor['Experience'] ?? ''); ?>" placeholder="Years of Experience">
                    </div>
                    <div class="form-group">
                        <label>Qualification</label>
                        <select name="qualification">
                            <option value="">Select</option>
                            <option value="MBBS" <?php echo (isset($doctor['Qualification']) && $doctor['Qualification'] == 'MBBS') ? 'selected' : ''; ?>>MBBS</option>
                            <option value="MD" <?php echo (isset($doctor['Qualification']) && $doctor['Qualification'] == 'MD') ? 'selected' : ''; ?>>MD</option>
                            <option value="MS" <?php echo (isset($doctor['Qualification']) && $doctor['Qualification'] == 'MS') ? 'selected' : ''; ?>>MS</option>
                            <option value="DM" <?php echo (isset($doctor['Qualification']) && $doctor['Qualification'] == 'DM') ? 'selected' : ''; ?>>DM</option>
                            <option value="DNB" <?php echo (isset($doctor['Qualification']) && $doctor['Qualification'] == 'DNB') ? 'selected' : ''; ?>>DNB</option>
                            <option value="MBBS, MD" <?php echo (isset($doctor['Qualification']) && $doctor['Qualification'] == 'MBBS, MD') ? 'selected' : ''; ?>>MBBS, MD</option>
                            <option value="MBBS, MS" <?php echo (isset($doctor['Qualification']) && $doctor['Qualification'] == 'MBBS, MS') ? 'selected' : ''; ?>>MBBS, MS</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Designation</label>
                        <select name="designation">
                            <option value="">Select</option>
                            <option value="Consultant" <?php echo (isset($doctor['Designation']) && $doctor['Designation'] == 'Consultant') ? 'selected' : ''; ?>>Consultant</option>
                            <option value="Senior Doctor" <?php echo (isset($doctor['Designation']) && $doctor['Designation'] == 'Senior Doctor') ? 'selected' : ''; ?>>Senior Doctor</option>
                            <option value="Specialist" <?php echo (isset($doctor['Designation']) && $doctor['Designation'] == 'Specialist') ? 'selected' : ''; ?>>Specialist</option>
                            <option value="Junior Doctor" <?php echo (isset($doctor['Designation']) && $doctor['Designation'] == 'Junior Doctor') ? 'selected' : ''; ?>>Junior Doctor</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Blood Group *</label>
                        <select name="bloodGroup" required>
                            <option value="">Select</option>
                            <option value="A+" <?php echo (isset($doctor['BloodGroup']) && $doctor['BloodGroup'] == 'A+') ? 'selected' : ''; ?>>A+</option>
                            <option value="A-" <?php echo (isset($doctor['BloodGroup']) && $doctor['BloodGroup'] == 'A-') ? 'selected' : ''; ?>>A-</option>
                            <option value="B+" <?php echo (isset($doctor['BloodGroup']) && $doctor['BloodGroup'] == 'B+') ? 'selected' : ''; ?>>B+</option>
                            <option value="B-" <?php echo (isset($doctor['BloodGroup']) && $doctor['BloodGroup'] == 'B-') ? 'selected' : ''; ?>>B-</option>
                            <option value="AB+" <?php echo (isset($doctor['BloodGroup']) && $doctor['BloodGroup'] == 'AB+') ? 'selected' : ''; ?>>AB+</option>
                            <option value="AB-" <?php echo (isset($doctor['BloodGroup']) && $doctor['BloodGroup'] == 'AB-') ? 'selected' : ''; ?>>AB-</option>
                            <option value="O+" <?php echo (isset($doctor['BloodGroup']) && $doctor['BloodGroup'] == 'O+') ? 'selected' : ''; ?>>O+</option>
                            <option value="O-" <?php echo (isset($doctor['BloodGroup']) && $doctor['BloodGroup'] == 'O-') ? 'selected' : ''; ?>>O-</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Rating (0-5)</label>
                        <input type="number" name="rating" min="0" max="5" step="0.1" value="<?php echo htmlspecialchars($doctor['Rating'] ?? ''); ?>" placeholder="0.0">
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" name="address" value="<?php echo htmlspecialchars($doctor['Address'] ?? ''); ?>" placeholder="Enter Address">
                    </div>
                <div class="form-group">
    <label>Wilaya</label>
    <select name="wilaya">
        <option value="">Select Wilaya</option>
        <option value="01 - Adrar">01 - Adrar</option>
        <option value="02 - Chlef">02 - Chlef</option>
        <option value="03 - Laghouat">03 - Laghouat</option>
        <option value="04 - Oum El Bouaghi">04 - Oum El Bouaghi</option>
        <option value="05 - Batna">05 - Batna</option>
        <option value="06 - Béjaïa">06 - Béjaïa</option>
        <option value="07 - Biskra">07 - Biskra</option>
        <option value="08 - Béchar">08 - Béchar</option>
        <option value="09 - Blida">09 - Blida</option>
        <option value="10 - Bouira">10 - Bouira</option>
        <option value="11 - Tamanrasset">11 - Tamanrasset</option>
        <option value="12 - Tébessa">12 - Tébessa</option>
        <option value="13 - Tlemcen">13 - Tlemcen</option>
        <option value="14 - Tiaret">14 - Tiaret</option>
        <option value="15 - Tizi Ouzou">15 - Tizi Ouzou</option>
        <option value="16 - Algiers">16 - Algiers</option>
        <option value="17 - Djelfa">17 - Djelfa</option>
        <option value="18 - Jijel">18 - Jijel</option>
        <option value="19 - Sétif">19 - Sétif</option>
        <option value="20 - Saïda">20 - Saïda</option>
        <option value="21 - Skikda">21 - Skikda</option>
        <option value="22 - Sidi Bel Abbès">22 - Sidi Bel Abbès</option>
        <option value="23 - Annaba">23 - Annaba</option>
        <option value="24 - Guelma">24 - Guelma</option>
        <option value="25 - Constantine">25 - Constantine</option>
        <option value="26 - Médéa">26 - Médéa</option>
        <option value="27 - Mostaganem">27 - Mostaganem</option>
        <option value="28 - M'Sila">28 - M'Sila</option>
        <option value="29 - Mascara">29 - Mascara</option>
        <option value="30 - Ouargla">30 - Ouargla</option>
        <option value="31 - Oran">31 - Oran</option>
        <option value="32 - El Bayadh">32 - El Bayadh</option>
        <option value="33 - Illizi">33 - Illizi</option>
        <option value="34 - Bordj Bou Arréridj">34 - Bordj Bou Arréridj</option>
        <option value="35 - Boumerdès">35 - Boumerdès</option>
        <option value="36 - El Tarf">36 - El Tarf</option>
        <option value="37 - Tindouf">37 - Tindouf</option>
        <option value="38 - Tissemsilt">38 - Tissemsilt</option>
        <option value="39 - El Oued">39 - El Oued</option>
        <option value="40 - Khenchela">40 - Khenchela</option>
        <option value="41 - Souk Ahras">41 - Souk Ahras</option>
        <option value="42 - Tipaza">42 - Tipaza</option>
        <option value="43 - Mila">43 - Mila</option>
        <option value="44 - Aïn Defla">44 - Aïn Defla</option>
        <option value="45 - Naâma">45 - Naâma</option>
        <option value="46 - Aïn Témouchent">46 - Aïn Témouchent</option>
        <option value="47 - Ghardaïa">47 - Ghardaïa</option>
        <option value="48 - Relizane">48 - Relizane</option>
        <option value="49 - Timimoun">49 - Timimoun</option>
        <option value="50 - Bordj Badji Mokhtar">50 - Bordj Badji Mokhtar</option>
        <option value="51 - Ouled Djellal">51 - Ouled Djellal</option>
        <option value="52 - Béni Abbès">52 - Béni Abbès</option>
        <option value="53 - In Salah">53 - In Salah</option>
        <option value="54 - In Guezzam">54 - In Guezzam</option>
        <option value="55 - Touggourt">55 - Touggourt</option>
        <option value="56 - Djanet">56 - Djanet</option>
        <option value="57 - El M'Ghair">57 - El M'Ghair</option>
        <option value="58 - El Meniaa">58 - El Meniaa</option>
    </select>
</div>
                    <div class="form-group">
                        <label>Daira</label>
                        <input type="text" name="daira" value="<?php echo htmlspecialchars($doctor['Daira'] ?? ''); ?>" placeholder="Enter Daira">
                    </div>
                    <div class="form-group">
                        <label>Postal Code</label>
                        <input type="text" name="postalCode" value="<?php echo htmlspecialchars($doctor['PostalCode'] ?? ''); ?>" placeholder="Enter Postal Code">
                    </div>
                    
                    <!-- Specialties Section -->
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label>Specialties *</label>
                        <div class="specialty-checkboxes">
                            <?php foreach ($allSpecialties as $specialty): ?>
                                <label>
                                    <input type="checkbox" name="specialties[]" value="<?php echo $specialty['SpecialtyID']; ?>"
                                        <?php echo (in_array($specialty['SpecialtyID'], $doctorSpecialties)) ? 'checked' : ''; ?>>
                                    <?php echo htmlspecialchars($specialty['Name']); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Status Section -->
                    <div class="form-group">
                        <label>Status *</label>
                        <select name="status" required>
                            <option value="on" <?php echo (isset($doctor['Status']) && $doctor['Status'] == 'on') ? 'selected' : ''; ?>>Active</option>
                            <option value="off" <?php echo (isset($doctor['Status']) && $doctor['Status'] == 'off') ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Profile and Bio Tab -->
            <div class="tab-panel" id="profile">
                <?php if (!empty($doctor['Photo']) && file_exists('../' . $doctor['Photo'])): ?>
                <div class="current-photo">
                    <label>Current Photo</label>
                    <br>
                    <img src="../<?php echo htmlspecialchars($doctor['Photo']); ?>" alt="Current Photo">
                </div>
                <?php endif; ?>
                
                <div class="upload-section">
                    <label>Upload New Profile Photo</label>
                    <div class="upload-box" id="uploadBox" onclick="document.getElementById('profileUpload').click()">
                        <p>📷 Click here to upload new photo</p>
                        <p style="font-size: 0.9em; color: #666;">Accepted: JPG, PNG, GIF (Max 5MB)</p>
                        <input type="file" id="profileUpload" name="profilePhoto" accept="image/*" style="display: none;" onchange="previewImage(this)">
                    </div>
                    <div id="imagePreview" style="display: none; margin-top: 20px; text-align: center;">
                        <img id="preview" src="" alt="Preview">
                        <br>
                        <button type="button" onclick="removeImage()" class="btn-cancel" style="margin-top: 10px;">Remove Image</button>
                    </div>
                </div>
                <div class="form-group">
                    <label>Write Bio</label>
                    <textarea name="bio" rows="6" placeholder="Write your bio here..."><?php echo htmlspecialchars($doctor['Bio'] ?? ''); ?></textarea>
                </div>
            </div>

            <!-- Availability Tab -->
            <div class="tab-panel" id="availability">
                <div class="availability-grid">
                    <?php 
                    $days = [
                        'sunday' => 'Sunday',
                        'monday' => 'Monday',
                        'tuesday' => 'Tuesday',
                        'wednesday' => 'Wednesday',
                        'thursday' => 'Thursday',
                        'friday' => 'Friday',
                        'saturday' => 'Saturday'
                    ];
                    foreach ($days as $key => $day): 
                    $startTime = isset($schedule[$key]['StartTime']) ? $schedule[$key]['StartTime'] : '';
                    $endTime = isset($schedule[$key]['EndTime']) ? $schedule[$key]['EndTime'] : '';
                    ?>
                    <div class="day-schedule">
                        <h4><?php echo $day; ?></h4>
                        <div class="time-inputs">
                            <input type="time" name="<?php echo $key; ?>From" value="<?php echo htmlspecialchars($startTime); ?>" placeholder="From">
                            <input type="time" name="<?php echo $key; ?>To" value="<?php echo htmlspecialchars($endTime); ?>" placeholder="To">
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Account Details Tab -->
            <div class="tab-panel" id="account">
                <div class="form-grid">
                    <div class="form-group full-width">
                        <label>User Name</label>
                        <input type="text" name="username" value="<?php echo htmlspecialchars($doctor['Username'] ?? ''); ?>" placeholder="Enter username">
                    </div>
                    <div class="form-group full-width">
                        <label>New Password (leave blank to keep current)</label>
                        <input type="password" name="password" placeholder="New Password">
                        <p class="help-text">Your password must be 8-20 characters long, contain letters and numbers.</p>
                    </div>
                    <div class="form-group full-width">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirmPassword" placeholder="Confirm new password">
                    </div>
                </div>
            </div>

            <div class="form-actions">
                <button type="button" class="btn-cancel" onclick="window.location.href='../html/doctors.php'">Cancel</button>
                <button type="submit" class="btn-primary">Update Doctor Profile</button>
            </div>
        </form>
    </div>

    <script>
        // Set current date
        document.getElementById('currentDate').textContent = new Date().toLocaleDateString('en-US', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });

        // Image preview function
        function previewImage(input) {
            const preview = document.getElementById('preview');
            const imagePreview = document.getElementById('imagePreview');
            const uploadBox = document.getElementById('uploadBox');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    imagePreview.style.display = 'block';
                    uploadBox.style.display = 'none';
                };
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Remove image function
        function removeImage() {
            document.getElementById('profileUpload').value = '';
            document.getElementById('imagePreview').style.display = 'none';
            document.getElementById('uploadBox').style.display = 'block';
        }
    </script>
    <script src="../javascript/doctors.js"></script>
</body>

</html>
