<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Appointment</title>
    <link rel="stylesheet" href="..\css\app.css">
    <style>
        .edit-form {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn-primary {
            background: #3eb8b0;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <div class="nav-left">
                <div class="logo">
                    <div class="logo-icon">+</div>
                    <span>HopeCare</span>
                </div>
                <ul class="nav-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="app.php">Back to Appointments</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <div class="edit-form">
            <h1>Edit Appointment</h1>
            
            <?php
            // Get appointment ID from URL
            $appId = isset($_GET['id']) ? intval($_GET['id']) : 0;
            
            if ($appId > 0) {
                // Database connection
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "clinic_db";
                
                $conn = new mysqli($servername, $username, $password, $dbname);
                
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                
                // Get appointment data
                $sql = "SELECT * FROM book_app WHERE APPID = $appId";
                $result = $conn->query($sql);
                
                if ($result->num_rows > 0) {
                    $appointment = $result->fetch_assoc();
                    ?>
                    
                    <form id="editAppointmentForm" onsubmit="return updateAppointment(event)">
                        <input type="hidden" id="APPID" value="<?php echo $appointment['APPID']; ?>">
                        
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" id="email" value="<?php echo htmlspecialchars($appointment['Pemail']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone:</label>
                            <input type="tel" id="phone" value="<?php echo htmlspecialchars($appointment['Pphone']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="place">Place:</label>
                            <input type="text" id="place" value="<?php echo htmlspecialchars($appointment['APPplace']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="date">Date:</label>
                            <input type="date" id="date" value="<?php echo htmlspecialchars($appointment['APPdate']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="time">Time:</label>
                            <input type="time" id="time" value="<?php echo htmlspecialchars($appointment['APPtime']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="reason">Reason:</label>
                            <textarea id="reason" rows="3"><?php echo htmlspecialchars($appointment['APPreason']); ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="status">Status:</label>
                            <select id="status">
                                <option value="Scheduled" <?php echo $appointment['status'] == 'Scheduled' ? 'selected' : ''; ?>>Scheduled</option>
                                <option value="Confirmed" <?php echo $appointment['status'] == 'Confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                <option value="Cancelled" <?php echo $appointment['status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                <option value="Completed" <?php echo $appointment['status'] == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                            </select>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Update Appointment</button>
                            <button type="button" class="btn btn-secondary" onclick="window.location.href='app.php'">Cancel</button>
                        </div>
                    </form>
                    
                    <?php
                } else {
                    echo '<p>Appointment not found.</p>';
                }
                
                $conn->close();
            } else {
                echo '<p>Invalid appointment ID.</p>';
            }
            ?>
        </div>
    </main>

    <script>
    function updateAppointment(event) {
        event.preventDefault();
        
        const appointmentData = {
            APPID: document.getElementById('APPID').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            place: document.getElementById('place').value,
            date: document.getElementById('date').value,
            time: document.getElementById('time').value,
            reason: document.getElementById('reason').value,
            status: document.getElementById('status').value
        };
        
        // Send update request
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "../api/updateapp.php", true);
        xhr.setRequestHeader("Content-Type", "application/json");
        
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        alert('Appointment updated successfully!');
                        window.location.href = 'app.php';
                    } else {
                        alert('Error: ' + response.message);
                    }
                } else {
                    alert('Failed to update appointment');
                }
            }
        };
        
        xhr.send(JSON.stringify(appointmentData));
        return false;
    }
    </script>
</body>
</html>