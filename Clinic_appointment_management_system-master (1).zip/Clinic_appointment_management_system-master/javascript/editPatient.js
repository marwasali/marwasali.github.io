document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('appointmentForm');
    const cancelBtn = document.getElementById('cancelBtn');

    // Get patient ID from URL
    const params = new URLSearchParams(window.location.search);
    const patientId = params.get('id');

    if (!patientId) {
        alert("No patient ID provided");
        window.location.href = 'Patient.html';
        return;
    }

    // Fetch patient data
    fetch(`../api/getsinglepatient.php?id=${patientId}`)
        .then(res => res.json())
        .then(data => {
            if (!data || data.error) {
                alert(data?.error || "Error loading patient data");
                window.location.href = 'Patient.html';
                return;
            }

            // Fill form fields
            form.Pfirstname.value = data.Pfirstname || '';
            form.Plastname.value = data.Plastname || '';
            form.Pemail.value = data.Pemail || '';
            form.Pphone.value = data.Pphone || '';
            form.Paddress.value = data.Paddress || '';
            form.Pdate_of_birth.value = data.Pdate_of_birth || '';

            // Set gender radio
            if (data.Pgender === 'male') form.male.checked = true;
            else if (data.Pgender === 'female') form.female.checked = true;
        })
        .catch(err => {
            console.error(err);
            alert("Error fetching patient data. Check console.");
        });

    // Submit update
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(form);
        formData.append('PID', patientId); // include ID

        fetch('../api/editPatient.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                alert(data.message);
                window.location.href = 'Patient.html';
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(err => {
            console.error(err);
            alert('An error occurred. Check console.');
        });
    });

    // Cancel button
    cancelBtn.addEventListener('click', function() {
        if (confirm('Cancel editing? Unsaved changes will be lost.')) {
            window.location.href = 'Patient.html';
        }
    });
});

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.href = 'index.html';
    }
}
