// Get elements
const tableBody = document.getElementById("departmentTableBody");
const formContainer = document.getElementById("departmentFormContainer");
const form = document.getElementById("departmentForm");
const formTitle = document.getElementById("formTitle");
const editingRowIndexInput = document.getElementById("editingRowIndex");

// Open Add Form
function openAddForm() {
    formTitle.textContent = "Add Department";
    form.reset();
    editingRowIndexInput.value = "";
    formContainer.style.display = "block";
}

// Close Form
function closeForm() {
    formContainer.style.display = "none";
}

// Add or Edit Department
form.addEventListener("submit", function(e) {
    e.preventDefault();

    const name = document.getElementById("depName").value;
    const email = document.getElementById("depEmail").value;
    const phone = document.getElementById("depPhone").value;
    const location = document.getElementById("depLocation").value;
    const head = document.getElementById("depHead").value;
    const staff = document.getElementById("depStaff").value + " staff";

    const rowIndex = editingRowIndexInput.value;

    if (rowIndex === "") {
        // ADD NEW ROW
        const newRow = tableBody.insertRow();
        newRow.innerHTML = `
            <td>
                <div class="dep-info">
                    <h4>${name}</h4>
                    <p>${email}</p>
                </div>
            </td>
            <td>${phone}</td>
            <td>${location}</td>
            <td>${head}</td>
            <td>${staff}</td>
            <td class="actions-btns">
                <button class="btn-icon edit" onclick="editDepartment(this)">✏️</button>
                <button class="btn-icon delete" onclick="removeDepartment(this)">🗑️</button>
            </td>
        `;
    } else {
        // MODIFY EXISTING ROW
        const row = tableBody.rows[rowIndex];
        row.cells[0].innerHTML = `<div class="dep-info"><h4>${name}</h4><p>${email}</p></div>`;
        row.cells[1].textContent = phone;
        row.cells[2].textContent = location;
        row.cells[3].textContent = head;
        row.cells[4].textContent = staff;
    }

    closeForm();
});

// Edit a row
function editDepartment(button) {
    const row = button.closest("tr");
    const index = row.rowIndex - 1; // exclude table header
    editingRowIndexInput.value = index;

    formTitle.textContent = "Modify Department";
    document.getElementById("depName").value = row.cells[0].querySelector("h4").textContent;
    document.getElementById("depEmail").value = row.cells[0].querySelector("p").textContent;
    document.getElementById("depPhone").value = row.cells[1].textContent;
    document.getElementById("depLocation").value = row.cells[2].textContent;
    document.getElementById("depHead").value = row.cells[3].textContent;
    document.getElementById("depStaff").value = parseInt(row.cells[4].textContent);

    formContainer.style.display = "block";
}

// Remove a row
function removeDepartment(button) {
    if (confirm("Are you sure you want to delete this department?")) {
        const row = button.closest("tr");
        row.remove();
    }
}

function logout() {
    // Optional: you can clear any session or local storage if needed
    // localStorage.clear();
    
    // Redirect to homepage
    window.location.href = "index.html"; // change the path if your homepage is in another folder
}


