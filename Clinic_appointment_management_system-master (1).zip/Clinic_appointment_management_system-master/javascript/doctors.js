// Load doctors when page loads
document.addEventListener('DOMContentLoaded', () => {
    console.log('✅ doctors.js loaded successfully!');
    loadDoctorsGrid();
});

// Fetch and display all doctors
function loadDoctorsGrid() {
    const tbody = document.getElementById('doctorsTableBody');
    if (!tbody) {
        console.error('❌ Error: doctorsTableBody not found');
        return;
    }

    console.log('📡 Fetching doctors from database...');
    tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 20px;">Loading doctors...</td></tr>';

    // UPDATED PATH: Changed from ../php/ to ../api/
    fetch('../api/fetch_doctors.php')
        .then(response => {
            console.log('📡 Response received:', response.status);
            return response.json();
        })
        .then(doctors => {
            console.log('✅ Doctors data received:', doctors);
            
            if (doctors.error) {
                console.error('❌ Database error:', doctors.error);
                tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: red;">Error loading doctors: ' + doctors.error + '</td></tr>';
                return;
            }
            
            if (!doctors || doctors.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align: center;">No doctors found</td></tr>';
                return;
            }

            tbody.innerHTML = '';
            doctors.forEach(doctor => {
                console.log('Creating row for doctor:', doctor.DOCTORID);
                const row = createDoctorRow(doctor);
                tbody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('❌ Error fetching doctors:', error);
            tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: red;">Error loading doctors. Check console for details.</td></tr>';
        });
}

// Create a table row for a doctor - FIXED VERSION
function createDoctorRow(doctor) {
    const tr = document.createElement('tr');

    const statusClass = doctor.Status === 'on' ? 'status-online' : 'status-offline';
    const statusText = doctor.Status === 'on' ? 'Available' : 'Offline';
    const statusIcon = doctor.Status === 'on' ? '🟢' : '🔴';
    
    // IMPORTANT: Use Specialties (with 's') from the JOIN query
    const specialty = doctor.Specialties || 'N/A';

    // IMPORTANT: Use data-doctor-id attribute instead of onclick with template literals
    tr.innerHTML = `
        <td>${doctor.DOCTORID}</td>
        <td>
            <div class="patient-info">
                <h4>Dr. ${doctor.FirstName} ${doctor.LastName}</h4>
            </div>
        </td>
        <td>${specialty}</td>
        <td>${doctor.Experience || '0'} years</td>
        <td>${doctor.Mobile || 'N/A'}</td>
        <td>⭐ ${doctor.Rating || '0'}</td>
        <td><span class="${statusClass}">${statusIcon} ${statusText}</span></td>
        <td>
            <button class="btn-icon edit" data-action="edit" data-doctor-id="${doctor.DOCTORID}" title="Edit">✏️</button>
            <button class="btn-icon delete" data-action="delete" data-doctor-id="${doctor.DOCTORID}" title="Delete">🗑️</button>
            <button class="btn-icon view" data-action="view" data-doctor-id="${doctor.DOCTORID}" title="View">👁️</button>
        </td>
    `;

    // Add event listeners to buttons AFTER innerHTML is set
    const editBtn = tr.querySelector('[data-action="edit"]');
    const deleteBtn = tr.querySelector('[data-action="delete"]');
    const viewBtn = tr.querySelector('[data-action="view"]');

    if (editBtn) {
        editBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const doctorId = editBtn.getAttribute('data-doctor-id');
            console.log('✏️ Edit clicked for doctor ID:', doctorId);
            editDoctor(doctorId);
        });
    }

    if (deleteBtn) {
        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const doctorId = deleteBtn.getAttribute('data-doctor-id');
            console.log('🗑️ Delete clicked for doctor ID:', doctorId);
            deleteDoctor(doctorId);
        });
    }

    if (viewBtn) {
        viewBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const doctorId = viewBtn.getAttribute('data-doctor-id');
            console.log('👁️ View clicked for doctor ID:', doctorId, 'Type:', typeof doctorId);
            viewdoctor(doctorId);
        });
    }

    return tr;
}

// Edit doctor function - NO event parameter
function editDoctor(doctorId) {
    console.log('Redirecting to edit page for doctor ID:', doctorId);
    window.location.href = `../html/edit-doctor.php?id=${encodeURIComponent(doctorId)}`;
}

// View doctor function - NO event parameter
function viewdoctor(doctorId) {
    console.log('Redirecting to view page for doctor ID:', doctorId, 'Type:', typeof doctorId);
    window.location.href = `../html/view_doctor_profile.php?id=${encodeURIComponent(doctorId)}`;
}

// Delete doctor function - NO event parameter - UPDATED PATH
function deleteDoctor(doctorId) {
    if (confirm('Are you sure you want to delete this doctor?')) {
        console.log('Deleting doctor ID:', doctorId);
        
        // UPDATED PATH: Changed from ../php/ to ../api/
        fetch(`../api/delete_doctor.php?id=${encodeURIComponent(doctorId)}`, {
            method: 'GET'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('✅ Doctor deleted successfully');
                loadDoctorsGrid(); // Reload the table
                showNotification('Doctor deleted successfully', 'success');
            } else {
                console.error('❌ Error deleting doctor:', data.error);
                showNotification('Error deleting doctor: ' + (data.error || 'Unknown error'), 'error');
            }
        })
        .catch(error => {
            console.error('❌ Error deleting doctor:', error);
            showNotification('Error deleting doctor', 'error');
        });
    }
}

// Show notification function
function showNotification(message, type = 'info') {
    // Remove existing notification if any
    const existing = document.querySelector('.notification-toast');
    if (existing) {
        existing.remove();
    }

    const notification = document.createElement('div');
    notification.className = 'notification-toast';
    
    const bgColor = type === 'error' ? '#f56565' : type === 'success' ? '#48bb78' : '#38b2ac';
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${bgColor};
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
        font-family: Arial, sans-serif;
        max-width: 350px;
    `;
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Add animation styles if not already present
    if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(400px); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(400px); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

console.log('✅ All functions loaded successfully');

// Tab switching functionality
document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.form-tab');
    const tabPanels = document.querySelectorAll('.tab-panel');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetTab = this.getAttribute('data-tab');
            
            // Remove active class from all tabs and panels
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabPanels.forEach(panel => panel.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding panel
            this.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
        });
    });
    
    // Form validation for password confirmation
    const form = document.getElementById('addDoctorForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            const password = document.querySelector('input[name="password"]');
            const confirmPassword = document.querySelector('input[name="confirmPassword"]');
            
            if (password && confirmPassword && password.value && password.value !== confirmPassword.value) {
                e.preventDefault();
                alert('Passwords do not match!');
                return false;
            }
            
            // Check if at least one specialty is selected
            const specialties = document.querySelectorAll('input[name="specialties[]"]:checked');
            if (specialties.length === 0) {
                e.preventDefault();
                alert('Please select at least one specialty!');
                return false;
            }
        });
    }
});
