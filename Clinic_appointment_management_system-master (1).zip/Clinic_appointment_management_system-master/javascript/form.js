document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('feedbackForm');

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(form);

        // Collect values
const FName = form.FName.value;
const FEmail = form.FEmail.value;
const FDepartment = form.FDepartment.value;
const FDeptRating = form.FDeptRating.value;
const FDoctor = form.FDoctor.value;
const FDocRating = form.FDocRating.value;
const FMessage = form.FMessage.value;

        // Validation
        if (!FName || !FEmail || !FDepartment || !FDeptRating || !FDoctor || !FDocRating) {
            alert("Please fill all required fields");
            return;
        }

        // Send to PHP
        fetch('../backend/feedback/form.php', {
            method: 'POST',
            body: JSON.stringify({
                FName,
                FEmail,
                FDepartment,
                FDeptRating,
                FDoctor,
                FDocRating,
                FMessage
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                alert(data.message);
                form.reset();
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(err => {
            console.error(err);
            alert('Error submitting feedback. Check console.');
        });
    });
});
