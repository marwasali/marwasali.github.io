// Get doctor data from PHP (passed via script tag in HTML)
let doctorProfile = typeof doctorData !== 'undefined' ? doctorData : null;

// State management
let currentReviewsShown = 3;
let allReviews = [];

// Load doctor profile
function loadDoctorProfile() {
    if (!doctorProfile) {
        console.error('No doctor data available');
        showNotification('Error loading doctor profile');
        return;
    }
    
    // Update greeting based on time
    updateGreeting();
    
    // Update date range
    updateDateRange();
    
    // Photo error handling
    const photoElem = document.getElementById('doctorPhoto');
    if (photoElem) {
        photoElem.onerror = function() {
            this.src = generatePlaceholderImage(doctorProfile.name);
        };
    }
    
    // The HTML is already populated by PHP, but we can add dynamic updates here if needed
    console.log('Doctor profile loaded:', doctorProfile);
}

// Generate placeholder image
function generatePlaceholderImage(name) {
    const initials = name.split(' ').map(n => n[0]).join('').toUpperCase();
    return `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Crect fill='%2338b2ac' width='200' height='200' rx='100'/%3E%3Ctext fill='white' font-size='80' font-family='Arial' x='50%25' y='50%25' text-anchor='middle' dy='.3em'%3E${initials}%3C/text%3E%3C/svg%3E`;
}

// Update greeting based on time of day
function updateGreeting() {
    const hour = new Date().getHours();
    let greeting = 'Good Morning,';
    
    if (hour >= 12 && hour < 18) {
        greeting = 'Good Afternoon,';
    } else if (hour >= 18) {
        greeting = 'Good Evening,';
    }
    
    const greetingElem = document.querySelector('.greeting');
    if (greetingElem) {
        greetingElem.textContent = greeting;
    }
}

// Update date range
function updateDateRange() {
    const today = new Date();
    const nextMonth = new Date(today);
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    
    const formatDate = (date) => {
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const year = date.getFullYear();
        return `${month}/${day}/${year}`;
    };
    
    const dateRange = `${formatDate(today)} - ${formatDate(nextMonth)}`;
    const dateRangeElem = document.getElementById('dateRangeDisplay');
    if (dateRangeElem) {
        dateRangeElem.textContent = dateRange;
    }
}

// Tab switching functionality
function setupProfileTabs() {
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.getAttribute('data-tab');
            switchProfileTab(tab, targetTab);
        });
    });
}

function switchProfileTab(clickedTab, targetTab) {
    // Remove active class from all tabs
    const allTabs = document.querySelectorAll('.tab');
    allTabs.forEach(t => t.classList.remove('active'));
    
    // Add active class to clicked tab
    clickedTab.classList.add('active');
    
    // Hide all tab contents
    const allContents = document.querySelectorAll('.tab-content');
    allContents.forEach(c => c.classList.remove('active'));
    
    // Show target content
    const targetContent = document.getElementById(targetTab);
    if (targetContent) {
        targetContent.classList.add('active');
    }
}

// Consultation actions
function startChat() {
    if (!doctorProfile) {
        showNotification('Error: Doctor information not available');
        return;
    }
    showNotification('Starting chat consultation with ' + doctorProfile.name + '...');
    // In production, open chat interface
    console.log('Chat consultation started with doctor ID:', doctorProfile.id);
}

function startAudioCall() {
    if (!doctorProfile) {
        showNotification('Error: Doctor information not available');
        return;
    }
    showNotification('Initiating audio call with ' + doctorProfile.name + '...');
    // In production, initiate audio call
    console.log('Audio call started with doctor ID:', doctorProfile.id);
}

function startVideoCall() {
    if (!doctorProfile) {
        showNotification('Error: Doctor information not available');
        return;
    }
    showNotification('Initiating video call with ' + doctorProfile.name + '...');
    // In production, initiate video call
    console.log('Video call started with doctor ID:', doctorProfile.id);
}

// Book appointment
function bookAppointment() {
    if (!doctorProfile) {
        showNotification('Error: Doctor information not available');
        return;
    }
    
    const doctorName = doctorProfile.name;
    if (confirm(`Book an appointment with ${doctorName}?`)) {
        showNotification('Appointment booking initiated. Redirecting...');
        // In production, redirect to appointment booking page with doctor ID
        setTimeout(() => {
            console.log('Redirecting to appointment booking page for doctor ID:', doctorProfile.id);
            // Uncomment the line below when you have the appointment page ready
            // window.location.href = `../html/book-appointment.php?doctor_id=${doctorProfile.id}`;
        }, 1500);
    }
}

// Recommend doctor (for reviews functionality if you add it later)
function recommendDoctor(reviewId) {
    showNotification('Thank you for your feedback!');
    console.log(`Recommended doctor from review ${reviewId}`);
    // In production, send AJAX request to save recommendation
}

// Load more reviews (if you implement reviews later)
function loadMoreReviews() {
    currentReviewsShown += 3;
    // Fetch more reviews from database via AJAX
    console.log('Loading more reviews...');
}

// Show notification
function showNotification(message) {
    // Check if notification already exists
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }

    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #38b2ac;
        color: white;
        padding: 15px 25px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
        max-width: 350px;
        font-size: 14px;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Add animation styles if not already added
    if (!document.getElementById('notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(400px);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(400px);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Print profile
function printProfile() {
    window.print();
}

// Share profile
function shareProfile() {
    if (!doctorProfile) {
        showNotification('Error: Doctor information not available');
        return;
    }
    
    const doctorName = doctorProfile.name;
    const url = window.location.href;
    
    if (navigator.share) {
        navigator.share({
            title: doctorName,
            text: `Check out ${doctorName}'s profile on HopeCare`,
            url: url
        }).then(() => {
            showNotification('Profile shared successfully!');
        }).catch((error) => {
            console.log('Error sharing:', error);
            fallbackCopyLink(url);
        });
    } else {
        // Fallback: copy to clipboard
        fallbackCopyLink(url);
    }
}

// Fallback copy link function
function fallbackCopyLink(url) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(() => {
            showNotification('Profile link copied to clipboard!');
        }).catch(() => {
            showNotification('Unable to copy link');
        });
    } else {
        // Old browser fallback
        const textArea = document.createElement('textarea');
        textArea.value = url;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.select();
        try {
            document.execCommand('copy');
            showNotification('Profile link copied to clipboard!');
        } catch (err) {
            showNotification('Unable to copy link');
        }
        document.body.removeChild(textArea);
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    loadDoctorProfile();
    setupProfileTabs();
    
    // Add keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            // Return to doctors list page
            if (confirm('Go back to doctors list?')) {
                window.location.href = '../html/doctors.php';
            }
        }
    });
});

// Export functions for use in other files (for module systems)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        loadDoctorProfile,
        loadMoreReviews,
        bookAppointment,
        startChat,
        startAudioCall,
        startVideoCall,
        recommendDoctor,
        shareProfile,
        printProfile
    };
}
