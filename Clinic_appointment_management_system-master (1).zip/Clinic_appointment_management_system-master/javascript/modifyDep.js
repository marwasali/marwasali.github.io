
const editForm = document.getElementById("editDepartmentForm");

// Load department data from localStorage (or URL params)
const urlParams = new URLSearchParams(window.location.search);
const index = urlParams.get("index");
let departments = JSON.parse(localStorage.getItem("departments") || "[]");

if (departments[index]) {
    document.getElementById("departmentName").value = departments[index].name;
    document.getElementById("departmentHead").value = departments[index].head;
    document.getElementById("doctorsList").value = departments[index].doctors || "";
}

editForm.addEventListener("submit", function(e) {
    e.preventDefault();

    departments[index].name = document.getElementById("departmentName").value;
    departments[index].head = document.getElementById("departmentHead").value;
    departments[index].doctors = document.getElementById("doctorsList").value;

    localStorage.setItem("departments", JSON.stringify(departments));
    alert("Department updated!");
    window.location.href = "departments.html";
});
function logout() {
    // Optional: you can clear any session or local storage if needed
    // localStorage.clear();
    
    // Redirect to homepage
    window.location.href = "index.html"; // change the path if your homepage is in another folder
}




