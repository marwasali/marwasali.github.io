// Load appointments when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadAppointments();
});

// Function to load appointments from PHP API
async function loadAppointments() {
    try {
        // Show loading state
        const tableBody = document.querySelector('.app-table tbody');
        if (!tableBody) {
            console.error('Table body not found');
            return;
        }
        
        tableBody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align: center; padding: 40px;">
                    <div class="loading-spinner"></div> Loading appointments...
                </td>
            </tr>
        `;
        
        // Fetch data from PHP API
        const response = await fetch('../api/appointments.php');
        const result = await response.json();
        
        if (result.success) {
            renderAppointments(result.data);
        } else {
            throw new Error(result.message);
        }
    } catch (error) {
        console.error('Error loading appointments:', error);
        const tableBody = document.querySelector('.app-table tbody');
        tableBody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align: center; color: red; padding: 20px;">
                    Failed to load appointments: ${error.message}
                </td>
            </tr>
        `;
    }
}

// Function to render appointments in the table
function renderAppointments(appointments) {
    const tableBody = document.querySelector('.app-table tbody');
    
    if (!appointments || appointments.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align: center; padding: 40px; color: #666;">
                    No appointments found. <button onclick="addAppointment()" style="background: none; border: none; color: #3eb8b0; cursor: pointer; text-decoration: underline;">Add a new appointment</button>
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    
    appointments.forEach(appointment => {
        // Determine status class based on appointment status
        let statusClass = 'status-scheduled'; // Default
        
        if (appointment.status) {
            const statusLower = appointment.status.toLowerCase();
            if (statusLower.includes('confirm')) {
                statusClass = 'status-confirmed';
            } else if (statusLower.includes('cancel')) {
                statusClass = 'status-cancelled';
            } else if (statusLower.includes('complete')) {
                statusClass = 'status-completed';
            }
        }
        
        html += `
            <tr data-id="${appointment.id}">
                <td>
                    <div><strong>${appointment.patient_name}</strong></div>
                    <small style="color: #666;">${appointment.patient_email}</small><br>
                    <small style="color: #666;">${appointment.patient_phone}</small>
                </td>
                <td>
                    <div><strong>${appointment.doctor_name}</strong></div>
                    <small style="color: #666;">${appointment.department}</small>
                </td>
                <td>${appointment.appointment_date}</td>
                <td>${appointment.appointment_time}</td>
                <td>${appointment.place}</td>
                <td>
                    <span class="${statusClass}">${appointment.status}</span>
                </td>
                <td>${appointment.reason}</td>
                <td>
                    <i class="fas fa-edit edit-icon" onclick="editAppointment(${appointment.id})" 
                       title="Edit appointment"></i>
                    <i class="fas fa-trash delete-icon" onclick="deleteAppointment(${appointment.id})" 
                       title="Delete appointment"></i>
                </td>
            </tr>
        `;
    });
    
    tableBody.innerHTML = html;
}

// Function to edit an appointment
async function editAppointment(id) {
    try {
        // Fetch all appointments
        const response = await fetch(`../api/appointments.php`);
        const result = await response.json();
        
        if (result.success) {
            const appointment = result.data.find(a => a.id === id);
            if (appointment) {
                // Show edit form with current values
                const newEmail = prompt('Enter new email:', appointment.patient_email);
                const newPhone = prompt('Enter new phone:', appointment.patient_phone);
                const newPlace = prompt('Enter new place:', appointment.place);
                const newDate = prompt('Enter new date (YYYY-MM-DD):', appointment.raw_date);
                const newTime = prompt('Enter new time (HH:MM):', formatTimeForInput(appointment.raw_time));
                const newReason = prompt('Enter new reason:', appointment.reason);
                const newStatus = prompt('Enter new status (scheduled/confirmed/cancelled/completed):', appointment.status.toLowerCase());
                
                if (newEmail && newDate && newTime) {
                    // Format time for database
                    const formattedTime = formatTimeForDB(newTime);
                    
                    const updateData = {
                        id: id,
                        Email: newEmail,
                        Phone: newPhone || '',
                        APPlace: newPlace || 'Main Clinic',
                        APDate: newDate,
                        APTime: formattedTime,
                        APPreason: newReason || 'General Checkup',
                        status: newStatus || 'scheduled'
                    };
                    
                    const updateResponse = await fetch('../api/appointments.php', {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(updateData)
                    });
                    
                    const updateResult = await updateResponse.json();
                    
                    if (updateResult.success) {
                        alert('Appointment updated successfully!');
                        loadAppointments(); // Refresh the list
                    } else {
                        alert('Error: ' + updateResult.message);
                    }
                }
            }
        }
    } catch (error) {
        console.error('Error editing appointment:', error);
        alert('Failed to edit appointment');
    }
}

// Function to delete an appointment
async function deleteAppointment(id) {
    if (!confirm('Are you sure you want to delete this appointment?')) {
        return;
    }
    
    try {
        const response = await fetch(`../api/appointments.php`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: id })
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('Appointment deleted successfully');
            loadAppointments(); // Refresh the list
        } else {
            alert('Error: ' + result.message);
        }
    } catch (error) {
        console.error('Error deleting appointment:', error);
        alert('Failed to delete appointment');
    }
}

// Function to add a new appointment
async function addAppointment() {
    const email = prompt('Enter patient email:');
    if (!email) return;
    
    const phone = prompt('Enter patient phone:');
    const place = prompt('Enter appointment place:', 'Main Clinic');
    const date = prompt('Enter appointment date (YYYY-MM-DD):');
    if (!date) return;
    
    const time = prompt('Enter appointment time (HH:MM):');
    if (!time) return;
    
    const reason = prompt('Enter reason for appointment:', 'General Checkup');
    const status = prompt('Enter status (scheduled/confirmed/cancelled/completed):', 'scheduled');
    
    // Format time for database
    const formattedTime = formatTimeForDB(time);
    
    const appointmentData = {
        Email: email,
        Phone: phone || '',
        APPlace: place || 'Main Clinic',
        APDate: date,
        APTime: formattedTime,
        APPreason: reason || 'General Checkup',
        status: status || 'scheduled'
    };
    
    try {
        const response = await fetch('../api/appointments.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(appointmentData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('Appointment added successfully!');
            loadAppointments(); // Refresh the list
        } else {
            alert('Error: ' + result.message);
        }
    } catch (error) {
        console.error('Error adding appointment:', error);
        alert('Failed to add appointment');
    }
}

// Helper function to format time for input (HH:MM)
function formatTimeForInput(timeString) {
    if (!timeString || timeString === 'Not Set') return '09:00';
    const time = new Date(`1970-01-01T${timeString}`);
    if (isNaN(time.getTime())) return '09:00';
    return time.toTimeString().slice(0, 5); // Returns HH:MM
}

// Helper function to format time for database (HH:MM:SS)
function formatTimeForDB(timeString) {
    if (!timeString) return '09:00:00';
    // Add seconds if not present
    if (timeString.length === 5) {
        return timeString + ':00';
    }
    return timeString;
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.href = 'login.html';
    }
}

// Add CSS for loading spinner if not already present
if (!document.querySelector('#loading-styles')) {
    const style = document.createElement('style');
    style.id = 'loading-styles';
    style.textContent = `
        .loading-spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #3498db;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            display: inline-block;
            margin-right: 10px;
            vertical-align: middle;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(style);
}