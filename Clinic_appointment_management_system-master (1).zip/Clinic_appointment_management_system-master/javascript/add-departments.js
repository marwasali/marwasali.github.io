const addForm = document.getElementById("addDepartmentForm");

addForm.addEventListener("submit", function(e) {
    e.preventDefault();

    const name = document.getElementById("departmentName").value;
    const email = document.getElementById("departmentEmail").value;
    const phone = document.getElementById("departmentPhone").value;
    const location = document.getElementById("departmentLocation").value;
    const head = document.getElementById("departmentHead").value;
    const staff = document.getElementById("staffCount").value;

    // Save department in localStorage or send to backend (for simplicity, using localStorage)
    let departments = JSON.parse(localStorage.getItem("departments") || "[]");
    departments.push({ name, email, phone, location, head, staff });
    localStorage.setItem("departments", JSON.stringify(departments));

    alert("Department added successfully!");
    window.location.href = "departments.html";
});

function logout() {
    // Optional: you can clear any session or local storage if needed
    // localStorage.clear();
    
    // Redirect to homepage
    window.location.href = "index.html"; // change the path if your homepage is in another folder
}

