document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('appointmentForm');
    const cancelBtn = document.getElementById('cancelBtn');

    // Set max date to today for date of birth
    const dobInput = document.getElementById('Pdate_of_birth');
    if (dobInput) {
        const today = new Date().toISOString().split('T')[0];
        dobInput.setAttribute('max', today);
    }

    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(form);

        // Validate required fields
        const required = ['Pfirstname', 'Plastname', 'Pemail', 'Pphone', 'Paddress', 'Pdate_of_birth', 'Pgender'];
        let missing = [];

        required.forEach(field => {
            if (!formData.get(field) || formData.get(field).trim() === '') {
                missing.push(field);
            }
        });

        if (missing.length > 0) {
            alert('Please fill all required fields: ' + missing.join(', '));
            return;
        }

        // Validate email
        const email = formData.get('Pemail');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Please enter a valid email address');
            return;
        }

        // Send data to server
        fetch('../api/addPatient.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                alert(data.message);
                window.location.href = 'Patient.html';
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(err => {
            console.error(err);
            alert('An error occurred. Please check console.');
        });
    });

    // Cancel button
    cancelBtn.addEventListener('click', function() {
        if (confirm('Cancel adding? Unsaved changes will be lost.')) {
            window.location.href = 'Patient.html';
        }
    });
});

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.href = 'index.html';
    }
}
