// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Get the form element
    const form = document.getElementById('appointmentForm');
    
    if (form) {
        // Set minimum date to today
        const dateInput = document.getElementById('date');
        if (dateInput) {
            const today = new Date().toISOString().split('T')[0];
            dateInput.min = today;
        }
    }
});

// Handle appointment booking
async function bookAppointment() {
    console.log('Booking appointment...');
    
    // Get form data - ONLY the fields that are in your database table
    const formData = {
        email: document.getElementById('email').value.trim(),
        phone: document.getElementById('phone').value.trim(),
        place: document.getElementById('place').value.trim(),
        date: document.getElementById('date').value,
        time: document.getElementById('time').value,
        reason: document.getElementById('reason').value.trim() || ''
        // Note: We're NOT including username, docusername, department
        // because they're not in your book_app table
    };
    
    console.log('Form data being sent:', formData);
    
    // Validation - check only the fields that go to database
    if (!formData.email || !formData.phone || !formData.place || !formData.date || !formData.time) {
        alert('Please fill in all required fields!');
        return;
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
        alert('Please enter a valid email address!');
        return;
    }
    
    // Validate phone format (simple validation)
    const phoneRegex = /^[0-9\-\+]{9,15}$/;
    if (!phoneRegex.test(formData.phone.replace(/\s/g, ''))) {
        alert('Please enter a valid phone number!');
        return;
    }
    
    try {
        // Send data to server
        const response = await fetch('../api/bookapp.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });
        
        // First get the raw response text
        const responseText = await response.text();
        console.log('Raw server response:', responseText);
        
        // Try to parse JSON
        let result;
        try {
            result = JSON.parse(responseText);
        } catch (parseError) {
            console.error('Failed to parse JSON:', parseError);
            console.error('Response text was:', responseText);
            alert('Server returned an invalid response. Please check console for details.');
            return;
        }
        
        console.log('Parsed server response:', result);
        
        if (result.success) {
            alert('Appointment booked successfully!');
            // Reset the form
            document.getElementById('appointmentForm').reset();
            
            // Optional: Redirect to appointments page after 2 seconds
            setTimeout(() => {
                window.location.href = '../html/app.html';
            }, 2000);
        } else {
            alert('Error: ' + (result.message || 'Unknown error occurred'));
        }
        
    } catch (error) {
        console.error('Network error:', error);
        alert('Network error. Please check your connection and try again.');
    }
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        // Clear any stored data
        localStorage.clear();
        sessionStorage.clear();
        
        // Redirect to home/login page
        window.location.href = '../index.html';
    }
}

// Test function for debugging
function testDirect() {
    // Simple test without using the form
    const testData = {
        email: 'test@example.com',
        phone: '0555555555',
        place: 'Room 1',
        date: '2024-12-25',
        time: '10:00',
        reason: 'Test appointment'
    };
    
    fetch('../api/bookapp.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(testData)
    })
    .then(response => response.text())
    .then(text => {
        console.log('Test response:', text);
        try {
            const data = JSON.parse(text);
            alert(data.message);
        } catch (e) {
            alert('Response: ' + text);
        }
    })
    .catch(error => console.error('Error:', error));
}