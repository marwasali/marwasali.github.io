document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.querySelector('.patients-table tbody');
    
    // Correct path from Patient.js to Patient.php
    const phpUrl = '../api/Patient.php';
    
    console.log('Fetching patients from:', phpUrl);
    
    fetch(phpUrl)
        .then(res => {
            console.log('Response status:', res.status, res.statusText);
            if (!res.ok) {
                throw new Error(`HTTP error! Status: ${res.status}`);
            }
            return res.json();
        })
        .then(response => {
            console.log('Success! Response:', response);
            
            if (response.success && response.data && response.data.length > 0) {
                tableBody.innerHTML = '';
                
                response.data.forEach(patient => {
                    // Format date for better display
                    let formattedDate = '';
                    if (patient.Pdate_of_birth) {
                        const dateObj = new Date(patient.Pdate_of_birth);
                        if (!isNaN(dateObj)) {
                            formattedDate = dateObj.toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric'
                            });
                        }
                    }
                    
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${patient.PID}</td>
                        <td>${patient.Pfirstname}</td>
                        <td>${patient.Plastname}</td>
                        <td>${patient.Pemail}</td>
                        <td>${patient.Pphone || 'N/A'}</td>
                        <td>${patient.Paddress || 'N/A'}</td>
                        <td>${formattedDate || patient.Pdate_of_birth || 'N/A'}</td>
                        <td>${patient.Pgender || 'N/A'}</td>
                        <td>
                            <button class="action-btn edit-btn" onclick="editPatient(${patient.PID})">✏️ Edit</button>
                            <button class="action-btn delete-btn" onclick="deletePatient(${patient.PID})">🗑️ Delete</button>
                        </td>
                    `;
                    tableBody.appendChild(row);
                });
                
                console.log(`Displayed ${response.count} patients`);
            } else {
                tableBody.innerHTML = '<tr><td colspan="9" style="text-align:center; padding: 20px; color: #666;">No patients found in database</td></tr>';
                console.log('No patients in database');
            }
        })
        .catch(err => {
            console.error('Fetch error details:', err);
            tableBody.innerHTML = `
                <tr>
                    <td colspan="9" style="text-align:center; color:red; padding: 20px;">
                        Error loading patients.<br>
                        ${err.message}<br>
                        Check browser console (F12) for details
                    </td>
                </tr>
            `;
        });
});

function editPatient(id) {
    console.log('Editing patient ID:', id);
    window.location.href = `editPatient.html?id=${id}`;
}

function deletePatient(id) {
    if (confirm(`Are you sure you want to delete patient ID ${id}?`)) {
        console.log('Deleting patient ID:', id);
        
        // Correct path for delete
        fetch(`../api/deletePatient.php?id=${id}`)
            .then(res => {
                console.log('Delete response status:', res.status);
                if (!res.ok) {
                    throw new Error(`HTTP error! Status: ${res.status}`);
                }
                return res.json();
            })
            .then(data => {
                console.log('Delete response:', data);
                alert(data.message || (data.status === 'success' ? 'Patient deleted successfully' : 'Error deleting patient'));
                location.reload(); // Refresh to show updated list
            })
            .catch(err => {
                console.error('Delete error:', err);
                alert('Error deleting patient. Check console for details.');
            });
    }
}
