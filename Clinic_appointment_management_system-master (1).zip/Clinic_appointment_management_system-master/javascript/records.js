// Medical Records Management System
let editId = null;
let deleteId = null;
let records = [];

// Initialize everything when DOM is loaded
document.addEventListener("DOMContentLoaded", function() {
    console.log("Initializing Medical Records System...");
    
    // Load all records
    loadRecords();
    
    // Set default date
    setDefaultDate();
    
    // Setup event listeners
    setupEventListeners();
    
    console.log("System initialized successfully");
});

// Set default date to today
function setDefaultDate() {
    const today = new Date().toISOString().split('T')[0];
    const dateInput = document.getElementById('recordDate');
    if (dateInput && !dateInput.value) {
        dateInput.value = today;
    }
}

// Setup all event listeners
function setupEventListeners() {
    // Add Record button
    const addRecordBtn = document.getElementById('addRecordBtn');
    if (addRecordBtn) {
        addRecordBtn.addEventListener('click', showAddForm);
    }
    
    // Close form button
    const closeFormBtn = document.getElementById('closeFormBtn');
    if (closeFormBtn) {
        closeFormBtn.addEventListener('click', hideForm);
    }
    
    // Cancel form button
    const cancelFormBtn = document.getElementById('cancelFormBtn');
    if (cancelFormBtn) {
        cancelFormBtn.addEventListener('click', hideForm);
    }
    
    // Form submission
    const recordForm = document.getElementById('recordForm');
    if (recordForm) {
        recordForm.addEventListener('submit', saveRecord);
    }
    
    // Delete modal buttons
    const closeDeleteModalBtn = document.getElementById('closeDeleteModalBtn');
    if (closeDeleteModalBtn) {
        closeDeleteModalBtn.addEventListener('click', closeDeleteModal);
    }
    
    const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
    if (cancelDeleteBtn) {
        cancelDeleteBtn.addEventListener('click', closeDeleteModal);
    }
    
    const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
    if (confirmDeleteBtn) {
        confirmDeleteBtn.addEventListener('click', confirmDelete);
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', logout);
    }
}

// Show add form
function showAddForm(event) {
    if (event) event.preventDefault();
    
    console.log("Showing add form...");
    editId = null;
    document.getElementById("formTitle").innerText = "Add New Record";
    document.getElementById("recordForm").reset();
    setDefaultDate();
    document.getElementById("recordFormContainer").classList.add("show");
}

// Hide form
function hideForm(event) {
    if (event) event.preventDefault();
    
    console.log("Hiding form...");
    document.getElementById("recordFormContainer").classList.remove("show");
    editId = null;
}

// Save record (add or update)
function saveRecord(event) {
    event.preventDefault();
    
    // Get form values
    const patientName = document.getElementById("patientName").value.trim();
    const doctorName = document.getElementById("doctorName").value.trim();
    const recordDate = document.getElementById("recordDate").value;
    const diagnosis = document.getElementById("diagnosis").value.trim();
    const treatment = document.getElementById("treatment").value.trim();
    
    // Validation
    if (!patientName || !doctorName || !recordDate || !diagnosis || !treatment) {
        alert("Please fill in all required fields!");
        return;
    }
    
    // Prepare data
    const recordData = {
        id: editId,
        patient_name: patientName,
        doctor_name: doctorName,
        record_date: recordDate,
        diagnosis: diagnosis,
        treatment: treatment
    };
    
    console.log("Saving record:", recordData);
    
    // Send to server
    fetch("../api/records.php", {
        method: "POST",
        headers: { 
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        body: JSON.stringify(recordData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        console.log("Server response:", data);
        if (data.success) {
            alert("Record saved successfully!");
            hideForm();
            loadRecords();
        } else {
            alert("Failed to save record. Please try again.");
        }
    })
    .catch(error => {
        console.error("Error saving record:", error);
        alert("Error saving record. Please check console for details.");
    });
}

// Load all records
function loadRecords() {
    console.log("Loading records...");
    
    fetch("../api/records.php")
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log("Records loaded:", data);
            records = data;
            renderRecordsTable();
        })
        .catch(error => {
            console.error("Error loading records:", error);
            document.getElementById("recordsTableBody").innerHTML = 
                `<tr><td colspan="7" style="text-align: center; color: #f56565;">Error loading records: ${error.message}</td></tr>`;
        });
}

// Render records table
function renderRecordsTable() {
    const tbody = document.getElementById("recordsTableBody");
    
    if (!records || records.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align: center;">No records found. Add your first record!</td></tr>`;
        return;
    }
    
    tbody.innerHTML = "";
    
    records.forEach(record => {
        const row = document.createElement("tr");
        
        row.innerHTML = `
            <td data-label="Record ID">${record.RECORDSID || record.id}</td>
            <td data-label="Patient Name">${record.patient_name}</td>
            <td data-label="Doctor">${record.doctor_name}</td>
            <td data-label="Date">${record.record_date}</td>
            <td data-label="Diagnosis">${record.diagnosis}</td>
            <td data-label="Treatment">${record.treatment}</td>
            <td data-label="Actions">
                <div class="action-buttons">
                    <button class="btn-action edit-btn" data-id="${record.RECORDSID || record.id}">Edit</button>
                    <button class="btn-action btn-delete delete-btn" data-id="${record.RECORDSID || record.id}">Delete</button>
                </div>
            </td>
        `;
        
        tbody.appendChild(row);
    });
    
    // Add event listeners to edit and delete buttons
    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            editRecord(this.getAttribute('data-id'));
        });
    });
    
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            openDeleteModal(this.getAttribute('data-id'));
        });
    });
}

// Edit record
function editRecord(id) {
    console.log("Editing record ID:", id);
    
    const record = records.find(r => (r.RECORDSID || r.id) == id);
    if (!record) {
        alert("Record not found!");
        return;
    }
    
    editId = id;
    document.getElementById("formTitle").innerText = "Edit Record";
    
    // Populate form
    document.getElementById("patientName").value = record.patient_name;
    document.getElementById("doctorName").value = record.doctor_name;
    document.getElementById("recordDate").value = record.record_date;
    document.getElementById("diagnosis").value = record.diagnosis;
    document.getElementById("treatment").value = record.treatment;
    
    // Show form
    document.getElementById("recordFormContainer").classList.add("show");
}

// Open delete modal
function openDeleteModal(id) {
    console.log("Opening delete modal for ID:", id);
    deleteId = id;
    document.getElementById("deleteModal").classList.add("show");
}

// Close delete modal
function closeDeleteModal() {
    document.getElementById("deleteModal").classList.remove("show");
    deleteId = null;
}

// Confirm and delete record
function confirmDelete() {
    if (!deleteId) return;
    
    console.log("Deleting record ID:", deleteId);
    
    fetch(`../api/records.php?id=${deleteId}`, { 
        method: "DELETE"
    })
    .then(response => response.json())
    .then(data => {
        console.log("Delete response:", data);
        if (data.success) {
            alert("Record deleted successfully!");
            closeDeleteModal();
            loadRecords();
        } else {
            alert("Failed to delete record.");
        }
    })
    .catch(error => {
        console.error("Error deleting record:", error);
        alert("Error deleting record. Please check console for details.");
    });
}

// Logout function
function logout() {
    if (confirm("Are you sure you want to logout?")) {
        // Clear any session data
        sessionStorage.clear();
        localStorage.clear();
        
        // Redirect to login page
        window.location.href = "../html/index.html";
    }
}
